﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace KaloriKolik2
{
    public partial class KiloVer : System.Web.UI.Page
    {

        sqlbaglanti baglan = new sqlbaglanti();

        protected void Page_Load(object sender, EventArgs e)
        {
            if(Page.IsPostBack == false)
            {
                DataList1.Visible = false;
                DataList2.Visible = false;
                DataList3.Visible = false;
                DataList4.Visible = false;
                DataList5.Visible = false;
                DataList6.Visible = false;
                DataList7.Visible = false;
                DataList8.Visible = false;
                DataList9.Visible = false;
                DataList10.Visible = false;
                DataList11.Visible = false;
                DataList12.Visible = false;
                DataList13.Visible = false;
            }
           

            SqlCommand cmdegzersiz1 = new SqlCommand("Select * from Besinler where Besin_Category_ID =5 or Besin_Category_ID =1 or Besin_Category_ID =17 or Besin_Category_ID =24 order by Besin_Adı", baglan.baglan());

             SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

             DataList1.DataSource = dregzersiz1;

             DataList1.DataBind();

            SqlCommand cmdegzersiz2 = new SqlCommand("Select * from Besinler where Besin_Category_ID =7 or Besin_Category_ID =22  order by Besin_Adı", baglan.baglan());

            SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

            DataList2.DataSource = dregzersiz2;

            DataList2.DataBind();

            SqlCommand cmdegzersiz3= new SqlCommand("Select * from Besinler where Besin_Category_ID =21  order by Besin_Adı", baglan.baglan());

            SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

            DataList3.DataSource = dregzersiz3;

            DataList3.DataBind();

            SqlCommand cmdegzersiz4 = new SqlCommand("Select * from Besinler where Besin_Category_ID =2 or Besin_Category_ID =16 order by Besin_Adı", baglan.baglan());

            SqlDataReader dregzersiz4 = cmdegzersiz4.ExecuteReader();

            DataList4.DataSource = dregzersiz4;

            DataList4.DataBind();

            SqlCommand cmdegzersiz5 = new SqlCommand("Select * from Besinler where Besin_Category_ID =4 order by Besin_Adı", baglan.baglan());

            SqlDataReader dregzersiz5 = cmdegzersiz5.ExecuteReader();

            DataList5.DataSource = dregzersiz5;

            DataList5.DataBind();

            SqlCommand cmdegzersiz6 = new SqlCommand("Select * from Besinler where Besin_Category_ID =3 order by Besin_Adı", baglan.baglan());

            SqlDataReader dregzersiz6 = cmdegzersiz6.ExecuteReader();

            DataList6.DataSource = dregzersiz6;

            DataList6.DataBind();


            SqlCommand cmdegzersiz7 = new SqlCommand("Select * from Besinler where Besin_Category_ID =9 order by Besin_Adı", baglan.baglan());

            SqlDataReader dregzersiz7 = cmdegzersiz7.ExecuteReader();

            DataList7.DataSource = dregzersiz7;

            DataList7.DataBind();


            SqlCommand cmdegzersiz8 = new SqlCommand("Select * from Besinler where Besin_Category_ID =10 order by Besin_Adı", baglan.baglan());

            SqlDataReader dregzersiz8 = cmdegzersiz8.ExecuteReader();

            DataList8.DataSource = dregzersiz8;

            DataList8.DataBind();


            SqlCommand cmdegzersiz9 = new SqlCommand("Select * from Besinler where Besin_Category_ID =8 order by Besin_Adı", baglan.baglan());

            SqlDataReader dregzersiz9 = cmdegzersiz9.ExecuteReader();

            DataList9.DataSource = dregzersiz9;

            DataList9.DataBind();


            SqlCommand cmdegzersiz10 = new SqlCommand("Select * from Besinler where Besin_Category_ID =11 or Besin_Category_ID =12 order by Besin_Adı", baglan.baglan());

            SqlDataReader dregzersiz10 = cmdegzersiz10.ExecuteReader();

            DataList10.DataSource = dregzersiz10;

            DataList10.DataBind();


            SqlCommand cmdegzersiz11 = new SqlCommand("Select * from Besinler where Besin_Category_ID =13 or Besin_Category_ID =23 order by Besin_Adı", baglan.baglan());

            SqlDataReader dregzersiz11 = cmdegzersiz11.ExecuteReader();

            DataList11.DataSource = dregzersiz11;

            DataList11.DataBind();


            SqlCommand cmdegzersiz12 = new SqlCommand("Select * from Besinler where Besin_Category_ID =15 order by Besin_Adı", baglan.baglan());

            SqlDataReader dregzersiz12 = cmdegzersiz12.ExecuteReader();

            DataList12.DataSource = dregzersiz12;

            DataList12.DataBind();



            SqlCommand cmdegzersiz13 = new SqlCommand("Select * from Besinler where Besin_Category_ID =20 order by Besin_Adı", baglan.baglan());

            SqlDataReader dregzersiz13 = cmdegzersiz13.ExecuteReader();

            DataList13.DataSource = dregzersiz13;

            DataList13.DataBind();







        }


        // bu bölüm besin ekleme yapmak için

        protected void btn4click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;


            if (Label2.Text == "")
            {
                Label2.Text = btn.CommandArgument.ToString();
            }
            else if (Label2.Text != "" && Label3.Text=="")
            {
                Label3.Text = btn.CommandArgument.ToString();

            }
            else if (Label3.Text != "" && Label4.Text == "")
            {
                Label4.Text = btn.CommandArgument.ToString();

            }
            else if (Label4.Text != "" && Label5.Text == "")
            {
                Label5.Text = btn.CommandArgument.ToString();

            }
            else if (Label5.Text != "" && Label6.Text == "")
            {
                Label6.Text = btn.CommandArgument.ToString();

            }
            else if (Label6.Text != "" && Label7.Text == "")
            {
                Label7.Text = btn.CommandArgument.ToString();

            }
            else if (Label7.Text != "" && Label8.Text == "")
            {
                Label8.Text = btn.CommandArgument.ToString();

            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if (Label25.Text == "")
            {
                Label25.Text = btn.CommandArgument.ToString();
            }
            else if (Label25.Text != "" && Label26.Text == "")
            {
                Label26.Text = btn.CommandArgument.ToString();
            }
            else if (Label26.Text != "" && Label27.Text == "")
            {
                Label27.Text = btn.CommandArgument.ToString();
            }
            else if (Label27.Text != "" && Label28.Text == "")
            {
                Label28.Text = btn.CommandArgument.ToString();
            }
            else if (Label28.Text != "" && Label29.Text == "")
            {
                Label29.Text = btn.CommandArgument.ToString();
            }
            else if (Label29.Text != "" && Label30.Text == "")
            {
                Label30.Text = btn.CommandArgument.ToString();
            }
            else if (Label30.Text != "" && Label31.Text == "")
            {
                Label31.Text = btn.CommandArgument.ToString();
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if (Label10.Text == "")
            {
                Label10.Text = btn.CommandArgument.ToString();
            }
            else if (Label10.Text != "" && Label32.Text == "")
            {
                Label32.Text = btn.CommandArgument.ToString();
            }
            else if (Label32.Text != "" && Label33.Text == "")
            {
                Label33.Text = btn.CommandArgument.ToString();
            }
            else if (Label33.Text != "" && Label34.Text == "")
            {
                Label34.Text = btn.CommandArgument.ToString();
            }
            else if (Label34.Text != "" && Label35.Text == "")
            {
                Label35.Text = btn.CommandArgument.ToString();
            }
            else if (Label35.Text != "" && Label36.Text == "")
            {
                Label36.Text = btn.CommandArgument.ToString();
            }
            else if (Label36.Text != "" && Label37.Text == "")
            {
                Label37.Text = btn.CommandArgument.ToString();
            }
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if (Label39.Text == "")
            {
                Label39.Text = btn.CommandArgument.ToString();
            }
            else if (Label39.Text != "" && Label40.Text == "")
            {
                Label40.Text = btn.CommandArgument.ToString();
            }
            else if (Label40.Text != "" && Label41.Text == "")
            {
                Label41.Text = btn.CommandArgument.ToString();
            }
            else if (Label41.Text != "" && Label42.Text == "")
            {
                Label42.Text = btn.CommandArgument.ToString();
            }
            else if (Label42.Text != "" && Label43.Text == "")
            {
                Label43.Text = btn.CommandArgument.ToString();
            }
            else if (Label43.Text != "" && Label44.Text == "")
            {
                Label44.Text = btn.CommandArgument.ToString();
            }
            else if (Label44.Text != "" && Label45.Text == "")
            {
                Label45.Text = btn.CommandArgument.ToString();
            }
        }


        // bu bölüm besin silme için
       
        protected void Button6_Click(object sender, EventArgs e)
        {

            if (Label8.Text != "")
            {
                Label8.Text = "";
            }
            else if (Label8.Text == "" && Label7.Text != "")
            {
                Label7.Text = "";
            }
            else if (Label7.Text == "" && Label6.Text != "")
            {
                Label6.Text = "";
            }
            else if (Label6.Text == "" && Label5.Text != "")
            {
                Label5.Text = "";
            }
            else if (Label5.Text == "" && Label4.Text != "")
            {
                Label4.Text = "";
            }
            else if (Label4.Text == "" && Label3.Text != "")
            {
                Label3.Text = "";
            }
            else if (Label3.Text == "" && Label2.Text != "")
            {
                Label2.Text = "";
            }
        }

        protected void Button7_Click(object sender, EventArgs e)
        {

            if (Label31.Text != "")
            {
                Label31.Text = "";
            }
            else if (Label31.Text == "" && Label30.Text != "")
            {
                Label30.Text = "";
            }
            else if (Label30.Text == "" && Label29.Text != "")
            {
                Label29.Text = "";
            }
            else if (Label29.Text == "" && Label28.Text != "")
            {
                Label28.Text = "";
            }
            else if (Label28.Text == "" && Label27.Text != "")
            {
                Label27.Text = "";
            }
            else if (Label27.Text == "" && Label26.Text != "")
            {
                Label26.Text = "";
            }
            else if (Label26.Text == "" && Label25.Text != "")
            {
                Label25.Text = "";
            }
        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            if (Label37.Text != "")
            {
                Label37.Text = "";
            }
            else if (Label37.Text == "" && Label36.Text != "")
            {
                Label36.Text = "";
            }
            else if (Label36.Text == "" && Label35.Text != "")
            {
                Label35.Text = "";
            }
            else if (Label35.Text == "" && Label34.Text != "")
            {
                Label34.Text = "";
            }
            else if (Label34.Text == "" && Label33.Text != "")
            {
                Label33.Text = "";
            }
            else if (Label33.Text == "" && Label32.Text != "")
            {
                Label32.Text = "";
            }
            else if (Label32.Text == "" && Label10.Text != "")
            {
                Label10.Text = "";
            }
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            if (Label45.Text != "")
            {
                Label45.Text = "";
            }
            else if (Label45.Text == "" && Label44.Text != "")
            {
                Label44.Text = "";
            }
            else if (Label44.Text == "" && Label43.Text != "")
            {
                Label43.Text = "";
            }
            else if (Label43.Text == "" && Label42.Text != "")
            {
                Label42.Text = "";
            }
            else if (Label42.Text == "" && Label41.Text != "")
            {
                Label41.Text = "";
            }
            else if (Label41.Text == "" && Label40.Text != "")
            {
                Label40.Text = "";
            }
            else if (Label40.Text == "" && Label39.Text != "")
            {
                Label39.Text = "";
            }
        }

        protected void Button10_Click(object sender, EventArgs e)
        {

            Label2.Text = "";
            Label3.Text = "";
            Label4.Text = "";
            Label5.Text = "";
            Label6.Text = "";
            Label7.Text = "";
            Label8.Text = "";

        }

        protected void Button11_Click(object sender, EventArgs e)
        {

            Label25.Text = "";
            Label26.Text = "";
            Label27.Text = "";
            Label28.Text = "";
            Label29.Text = "";
            Label30.Text = "";
            Label31.Text = "";

        }

        protected void Button12_Click(object sender, EventArgs e)
        {

            Label10.Text = "";
            Label32.Text = "";
            Label33.Text = "";
            Label34.Text = "";
            Label35.Text = "";
            Label36.Text = "";
            Label37.Text = "";

        }

        protected void Button13_Click(object sender, EventArgs e)
        {
            Label39.Text = "";
            Label40.Text = "";
            Label41.Text = "";
            Label42.Text = "";
            Label43.Text = "";
            Label44.Text = "";
            Label45.Text = "";
        }


        // bu bölüm datalistlerin visible durumunu değiştirmek için

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataList1.Visible = true;
        }

        protected void Button14_Click(object sender, EventArgs e)
        {
            DataList1.Visible = false;
        }

        protected void Button15_Click(object sender, EventArgs e)
        {
            DataList2.Visible = true;
        }

        protected void Button16_Click(object sender, EventArgs e)
        {
            DataList2.Visible = false;
        }

        protected void Button17_Click(object sender, EventArgs e)
        {
            DataList3.Visible = true;
        }

        protected void Button18_Click(object sender, EventArgs e)
        {
            DataList3.Visible = false;
        }

        protected void Button19_Click(object sender, EventArgs e)
        {
            DataList4.Visible = true;
        }

        protected void Button20_Click(object sender, EventArgs e)
        {
            DataList4.Visible = false;
        }

        protected void Button21_Click(object sender, EventArgs e)
        {
            DataList5.Visible = true;
        }

        protected void Button22_Click(object sender, EventArgs e)
        {
            DataList5.Visible = false;
        }

        protected void Button23_Click(object sender, EventArgs e)
        {
            DataList6.Visible = true;
        }

        protected void Button24_Click(object sender, EventArgs e)
        {
            DataList6.Visible = false;
        }

        protected void Button25_Click(object sender, EventArgs e)
        {
            DataList7.Visible = true;
        }

        protected void Button26_Click(object sender, EventArgs e)
        {
            DataList7.Visible = false;
        }

        protected void Button27_Click(object sender, EventArgs e)
        {
            DataList8.Visible = true;
        }

        protected void Button28_Click(object sender, EventArgs e)
        {
            DataList8.Visible = false;
        }

        protected void Button29_Click(object sender, EventArgs e)
        {
            DataList9.Visible = true;
        }

        protected void Button30_Click(object sender, EventArgs e)
        {
            DataList9.Visible = false;
        }

        protected void Button31_Click(object sender, EventArgs e)
        {
            DataList10.Visible = true;
        }

        protected void Button32_Click(object sender, EventArgs e)
        {
            DataList10.Visible = false;
        }

        protected void Button33_Click(object sender, EventArgs e)
        {
            DataList11.Visible = true;
        }

        protected void Button34_Click(object sender, EventArgs e)
        {
            DataList11.Visible = false;
        }

        protected void Button35_Click(object sender, EventArgs e)
        {
            DataList12.Visible = true;
        }

        protected void Button36_Click(object sender, EventArgs e)
        {
            DataList12.Visible = false;
        }

        protected void Button37_Click(object sender, EventArgs e)
        {
            DataList13.Visible = true;
        }

        protected void Button38_Click(object sender, EventArgs e)
        {
            DataList13.Visible = false;
        }

    }
}