﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace KaloriKolik2
{
    public partial class besinara : System.Web.UI.Page
    {
        sqlbaglanti baglan = new sqlbaglanti();
        string aranankelime = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            aranankelime = Request.QueryString["aranankelime"];

            if(Page.IsPostBack == false)
            {

                SqlCommand cmdara = new SqlCommand("select * from Besinler where Besin_Adı like '%"+aranankelime+"%'",baglan.baglan());

                SqlDataReader drara = cmdara.ExecuteReader();

                DataList1.DataSource = drara;

                DataList1.DataBind();

            }

        }
    }
}