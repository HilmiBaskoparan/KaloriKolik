﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace KaloriKolik2
{
    public partial class Egzersiz : System.Web.UI.Page
    {

        sqlbaglanti baglan = new sqlbaglanti();

        protected void Page_Load(object sender, EventArgs e)
        {

            //egzersiz

            SqlCommand cmdegzersiz = new SqlCommand("Select * from Egzersiz", baglan.baglan());

            SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

            DataList1.DataSource = dregzersiz;

            DataList1.DataBind();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            double a = 0;

            double b = 0;

            double sonuc = 0;

            if(TextBox1.Text == "" || TextBox2.Text == "" || DropDownList1.Text == "Lütfen Bir Seçim Yapınız")
            {
                Label5.Text = "Lütfen Eksik Bilgileri Doldurun.";
            }

            if(DropDownList1.Text == "Kayak")
            {
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                sonuc = a * b * 0.083;
                Label5.Text = Convert.ToString(sonuc);
            }
            else if(DropDownList1.Text == "Bisiklet Sürme")
            {
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                sonuc = a * b * 0.142;
                Label5.Text = Convert.ToString(sonuc);
            }
            else if (DropDownList1.Text == "Balık Tutma")
            {
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                sonuc = a * b * 0.05;
                Label5.Text = Convert.ToString(sonuc);
            }
            else if (DropDownList1.Text == "Jimnastik, Şınav, Mekik")
            {
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                sonuc = a * b * 0.133;
                Label5.Text = Convert.ToString(sonuc);
            }
            else if (DropDownList1.Text == "Ağırlık Kaldırma")
            {
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                sonuc = a * b * 0.1;
                Label5.Text = Convert.ToString(sonuc);
            }
            else if (DropDownList1.Text == "Koşu")
            {
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                sonuc = a * b * 0.133;
                Label5.Text = Convert.ToString(sonuc);
            }
            else if (DropDownList1.Text == "Basketbol Maçı")
            {
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                sonuc = a * b * 0.1;
                Label5.Text = Convert.ToString(sonuc);
            }
            else if (DropDownList1.Text == "Futbol Maçı")
            {
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                sonuc = a * b * 0.117;
                Label5.Text = Convert.ToString(sonuc);
            }
            else if (DropDownList1.Text == "Masa Tenisi")
            {
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                sonuc = a * b * 0.067;
                Label5.Text = Convert.ToString(sonuc);
            }
            else if (DropDownList1.Text == "Tenis")
            {
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                sonuc = a * b * 0.117;
                Label5.Text = Convert.ToString(sonuc);
            }
            else if (DropDownList1.Text == "Voleybol Oynamak")
            {
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                sonuc = a * b * 0.05;
                Label5.Text = Convert.ToString(sonuc);
            }
            else if (DropDownList1.Text == "Yürüyüş")
            {
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                sonuc = a * b * 0.063;
                Label5.Text = Convert.ToString(sonuc);
            }
            else if (DropDownList1.Text == "Yüzme")
            {
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                sonuc = a * b * 0.1;
                Label5.Text = Convert.ToString(sonuc);
            }
            else if (DropDownList1.Text == "Bahçe İşleri")
            {
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                sonuc = a * b * 0.067;
                Label5.Text = Convert.ToString(sonuc);
            }

        }
    }
}