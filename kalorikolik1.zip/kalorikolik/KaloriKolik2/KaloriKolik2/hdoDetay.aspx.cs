﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace KaloriKolik2
{
    public partial class hdoDetay : System.Web.UI.Page
    {
        sqlbaglanti baglan = new sqlbaglanti();
        string MakaleID = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            MakaleID = Request.QueryString["MakaleID"];

            

            SqlCommand cmdmakale = new SqlCommand("Select * from Makale where MakaleID='" + MakaleID + "'", baglan.baglan());

            SqlDataReader drmakale = cmdmakale.ExecuteReader();

            DataList1.DataSource = drmakale;

            DataList1.DataBind();

        }
    }
}