﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace KaloriKolik2
{
    public partial class iletisim : System.Web.UI.Page
    {
        sqlbaglanti baglan = new sqlbaglanti();
        protected void Page_Load(object sender, EventArgs e)
        {
            //makale

            SqlCommand cmdiletisim = new SqlCommand("Select * from Iletisim", baglan.baglan());
            SqlDataReader driletisim = cmdiletisim.ExecuteReader();

            DataList1.DataSource = driletisim;
            DataList1.DataBind();
        }
    }
}