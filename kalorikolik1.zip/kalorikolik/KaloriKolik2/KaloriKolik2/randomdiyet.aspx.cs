﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


namespace KaloriKolik2
{
    public partial class randomdiyet : System.Web.UI.Page
    {
        sqlbaglanti baglan = new sqlbaglanti();

        protected void Page_Load(object sender, EventArgs e)
        {
         
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            if (TextBox1.Text == "")
            {
                TextBox1.Text = "Lütfen diyet istediğiniz kalori miktarını giriniz";
            }

            int i=1000;

            if (RadioButton1.Checked)
                i = 7;
            else if (RadioButton2.Checked)
                i = 1;
            else if (RadioButton3.Checked)
                i = 2;
            else if (RadioButton4.Checked)
                i = 3;
            else if (RadioButton5.Checked)
                i = 4;
            else if (RadioButton6.Checked)
                i = 5;
            else if (RadioButton7.Checked)
                i = 6;

            int a = int.Parse(TextBox1.Text);

            a -= 1000;
            a /= 200;

           

                    switch (a)
                    {
                        case 0:

                            SqlCommand cmdegzersiz8 = new SqlCommand("SELECT * FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not  Like '%"+i+"%' AND Besin_Category_ID = 5 and (Kalori >= 120 and Kalori <= 150) ORDER BY  NEWID()) AS T UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 1 and (Kalori >= 130 and Kalori <= 140)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 1 and(Kalori >= 30 and Kalori <= 45)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 2 and (Kalori >= 65 and Kalori <= 80)  ORDER BY  NEWID()) AS T   UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 17 and (Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()) AS T", baglan.baglan());

                            SqlDataReader dregzersiz = cmdegzersiz8.ExecuteReader();

                            DataList1.DataSource = dregzersiz;

                            DataList1.DataBind();


                            SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 3 AND (Kalori >= 55 AND Kalori <= 75)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 7 AND (Kalori >= 55 AND Kalori <= 80) ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 21 AND  (Kalori >= 200 AND Kalori <= 220) ORDER BY NEWID()) AS K ", baglan.baglan());

                            SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                            DataList2.DataSource = dregzersiz1;

                            DataList2.DataBind();


                            SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 105)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 7 AND (Kalori >= 100 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                            SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                            DataList3.DataSource = dregzersiz2;

                            DataList3.DataBind();


                            SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 12 AND (Kalori >= 125 AND Kalori <= 150)  ORDER BY NEWID() ) AS K ", baglan.baglan());

                            SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                            DataList4.DataSource = dregzersiz3;

                            DataList4.DataBind();

                            break;

                        case 1:

                            SqlCommand cmdegzersiz9 = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 5 and (Kalori >= 150 and Kalori <= 180)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM (Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 1 and(Kalori >= 150 and Kalori <= 160)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 1 and(Kalori >= 35 and Kalori <= 50)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 2 and (Kalori >= 80 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION   SELECT *   FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                            SqlDataReader dregzersiz9 = cmdegzersiz9.ExecuteReader();

                            DataList1.DataSource = dregzersiz9;

                            DataList1.DataBind();


                            SqlCommand cmdegzersiz11 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 3 AND (Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 7 AND (Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID()) AS K ", baglan.baglan());

                            SqlDataReader dregzersiz11 = cmdegzersiz11.ExecuteReader();

                            DataList2.DataSource = dregzersiz11;

                            DataList2.DataBind();


                            SqlCommand cmdegzersiz21 = new SqlCommand(" SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 95)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 55) ORDER BY NEWID()) AS K ", baglan.baglan());

                            SqlDataReader dregzersiz21 = cmdegzersiz21.ExecuteReader();

                            DataList3.DataSource = dregzersiz21;

                            DataList3.DataBind();


                            SqlCommand cmdegzersiz31 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 12 AND(Kalori >= 150 AND Kalori <= 175)  ORDER BY NEWID() ) AS K", baglan.baglan());

                            SqlDataReader dregzersiz31 = cmdegzersiz31.ExecuteReader();

                            DataList4.DataSource = dregzersiz31;

                            DataList4.DataBind();

                            break;

                        case 2:

                            SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 5 and(Kalori >= 180 and Kalori <= 210)  ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 1 and(Kalori >= 170 and Kalori <= 180) ORDER BY  NEWID()) AS T  UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 1 and(Kalori >= 40 and Kalori <= 55)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 1 and(Kalori >= 15 and Kalori <= 30)   ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 2 and(Kalori >= 80 and Kalori <= 95)   ORDER BY  NEWID()) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                            SqlDataReader dregzersiz111 = cmdegzersiz.ExecuteReader();

                            DataList1.DataSource = dregzersiz111;

                            DataList1.DataBind();


                            SqlCommand cmdegzersiz1111 = new SqlCommand("SELECT *  FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like  '%"+i+"%' AND Besin_Category_ID = 3 AND(Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 7 AND(Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 8 AND(Kalori >= 0 AND Kalori <= 60) ORDER BY NEWID() ) AS K  ", baglan.baglan());

                            SqlDataReader dregzersiz1111 = cmdegzersiz1111.ExecuteReader();

                            DataList2.DataSource = dregzersiz1111;

                            DataList2.DataBind();


                            SqlCommand cmdegzersiz211 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 115) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 85) ORDER BY NEWID() ) AS K ", baglan.baglan());

                            SqlDataReader dregzersiz211 = cmdegzersiz211.ExecuteReader();

                            DataList3.DataSource = dregzersiz211;

                            DataList3.DataBind();


                            SqlCommand cmdegzersiz311 = new SqlCommand("select * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 12 AND(Kalori >= 175 AND Kalori <= 200)  ORDER BY NEWID() ) AS K  ", baglan.baglan());

                            SqlDataReader dregzersiz311 = cmdegzersiz311.ExecuteReader();

                            DataList4.DataSource = dregzersiz311;

                            DataList4.DataBind();

                            break;

                        case 3:

                            SqlCommand cmdegzersiz44 = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 5 and(Kalori >= 210 and Kalori <= 240)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 1 and(Kalori >= 180 and Kalori <= 190)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 1 and(Kalori >= 20 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 2 and(Kalori >= 85 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T", baglan.baglan());

                            SqlDataReader dregzersiz44 = cmdegzersiz44.ExecuteReader();

                            DataList1.DataSource = dregzersiz44;

                            DataList1.DataBind();


                            SqlCommand cmdegzersiz45 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=21 AND (Kalori >=210 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 11 AND(Kalori >= 30 AND Kalori <= 60) ORDER BY NEWID()) AS K", baglan.baglan());

                            SqlDataReader dregzersiz45 = cmdegzersiz45.ExecuteReader();

                            DataList2.DataSource = dregzersiz45;

                            DataList2.DataBind();


                            SqlCommand cmdegzersiz46 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=3 AND (Kalori >=110 AND Kalori <=120)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=4 AND (Kalori >=70 AND Kalori <=85) ORDER BY NEWID ()) AS K", baglan.baglan());

                            SqlDataReader dregzersiz46 = cmdegzersiz46.ExecuteReader();

                            DataList3.DataSource = dregzersiz46;

                            DataList3.DataBind();


                            SqlCommand cmdegzersiz47 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=12 AND (Kalori >=100 AND Kalori <=112)  ORDER BY NEWID () ) AS K", baglan.baglan());

                            SqlDataReader dregzersiz47 = cmdegzersiz47.ExecuteReader();

                            DataList4.DataSource = dregzersiz47;

                            DataList4.DataBind();


                            break;

                        case 4:

                            SqlCommand cmdegzersiz37 = new SqlCommand("SELECT *FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=5 AND (Kalori >=175 AND Kalori <=210)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=200 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=40 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=35)ORDER BY  NEWID() )AS T", baglan.baglan());

                            SqlDataReader dregzersiz37 = cmdegzersiz37.ExecuteReader();

                            DataList1.DataSource = dregzersiz37;

                            DataList1.DataBind();


                            SqlCommand cmdegzersiz51 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                            SqlDataReader dregzersiz51 = cmdegzersiz51.ExecuteReader();

                            DataList2.DataSource = dregzersiz51;

                            DataList2.DataBind();


                            SqlCommand cmdegzersiz52 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=3 AND (Kalori >=140 AND Kalori <=150)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=135) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 90) ORDER BY NEWID()) AS K ", baglan.baglan());

                            SqlDataReader dregzersiz52 = cmdegzersiz52.ExecuteReader();

                            DataList3.DataSource = dregzersiz52;

                            DataList3.DataBind();


                            SqlCommand cmdegzersiz53 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=12 AND (Kalori >=225 AND Kalori <=250)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                            SqlDataReader dregzersiz53 = cmdegzersiz53.ExecuteReader();

                            DataList4.DataSource = dregzersiz53;

                            DataList4.DataBind();

                            break;

                        case 5:

                            SqlCommand cmdegzersiz61 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=5 AND (Kalori >=200 AND Kalori <=235)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=215 AND Kalori <=225) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=50 AND Kalori <=65) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T ", baglan.baglan());

                            SqlDataReader dregzersiz61 = cmdegzersiz61.ExecuteReader();

                            DataList1.DataSource = dregzersiz61;

                            DataList1.DataBind();


                            SqlCommand cmdegzersiz71 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID ()UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                            SqlDataReader dregzersiz71 = cmdegzersiz71.ExecuteReader();

                            DataList2.DataSource = dregzersiz71;

                            DataList2.DataBind();


                            SqlCommand cmdegzersiz72 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=3 AND (Kalori >=175 AND Kalori <=190)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID () ) AS K", baglan.baglan());

                            SqlDataReader dregzersiz72 = cmdegzersiz72.ExecuteReader();

                            DataList3.DataSource = dregzersiz72;

                            DataList3.DataBind();


                            SqlCommand cmdegzersiz73 = new SqlCommand(" SELECT *  FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=12 AND (Kalori >=125 AND Kalori <=138)  ORDER BY NEWID ()  ) AS K  ", baglan.baglan());

                            SqlDataReader dregzersiz73 = cmdegzersiz73.ExecuteReader();

                            DataList4.DataSource = dregzersiz73;

                            DataList4.DataBind();

                            break;

                        case 6:


                            SqlCommand cmdegzersiz65 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=5 AND (Kalori >=225 AND Kalori <=260)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=60 AND Kalori <=75) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori  <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                            SqlDataReader dregzersiz65 = cmdegzersiz65.ExecuteReader();

                            DataList1.DataSource = dregzersiz65;

                            DataList1.DataBind();


                            SqlCommand cmdegzersiz67 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=21 AND (Kalori >=220 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 65) ORDER BY NEWID())AS K  ", baglan.baglan());

                            SqlDataReader dregzersiz67 = cmdegzersiz67.ExecuteReader();

                            DataList2.DataSource = dregzersiz67;

                            DataList2.DataBind();


                            SqlCommand cmdegzersiz68 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=7 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=4 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 15 AND(Kalori >= 60 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                            SqlDataReader dregzersiz68 = cmdegzersiz68.ExecuteReader();

                            DataList3.DataSource = dregzersiz68;

                            DataList3.DataBind();


                            SqlCommand cmdegzersiz39 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=12 AND (Kalori >=138 AND Kalori <=150)  ORDER BY NEWID () ) AS K  ", baglan.baglan());

                            SqlDataReader dregzersiz39 = cmdegzersiz39.ExecuteReader();

                            DataList4.DataSource = dregzersiz39;

                            DataList4.DataBind();

                            break;

                        case 7:

                            SqlCommand cmdegzersiz87 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=290)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                            SqlDataReader dregzersiz87 = cmdegzersiz87.ExecuteReader();

                            DataList1.DataSource = dregzersiz87;

                            DataList1.DataBind();


                            SqlCommand cmdegzersiz89 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 8 AND(Kalori >= 40 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND  Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 4 AND(Kalori >= 60 AND Kalori <= 85) ORDER BY NEWID()) AS K  ", baglan.baglan());

                            SqlDataReader dregzersiz89 = cmdegzersiz89.ExecuteReader();

                            DataList2.DataSource = dregzersiz89;

                            DataList2.DataBind();


                            SqlCommand cmdegzersiz91 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=7 AND (Kalori >=136 AND Kalori <=145) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 4 AND(Kalori >= 121 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 15 AND(Kalori >= 63 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                            SqlDataReader dregzersiz91 = cmdegzersiz91.ExecuteReader();

                            DataList3.DataSource = dregzersiz91;

                            DataList3.DataBind();


                            SqlCommand cmdegzersiz92 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=12 AND (Kalori >=150 AND Kalori <=165)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                            SqlDataReader dregzersiz92 = cmdegzersiz92.ExecuteReader();

                            DataList4.DataSource = dregzersiz92;

                            DataList4.DataBind();

                            break;

                        case 8:

                            SqlCommand cmdegzersiz69 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                            SqlDataReader dregzersiz69 = cmdegzersiz69.ExecuteReader();

                            DataList1.DataSource = dregzersiz69;

                            DataList1.DataBind();


                            SqlCommand cmdegzersiz70 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=21 AND (Kalori >=240 AND Kalori <=260) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 8 AND(Kalori >= 45 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 115) ORDER BY NEWID()) AS K  ", baglan.baglan());

                            SqlDataReader dregzersiz70 = cmdegzersiz70.ExecuteReader();

                            DataList2.DataSource = dregzersiz70;

                            DataList2.DataBind();


                            SqlCommand cmdegzersiz777 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=3 AND (Kalori >=150 AND Kalori <=160)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=7 AND (Kalori >=155 AND Kalori <=165) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=4 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID ()) AS K", baglan.baglan());

                            SqlDataReader dregzersiz777 = cmdegzersiz777.ExecuteReader();

                            DataList3.DataSource = dregzersiz777;

                            DataList3.DataBind();


                            SqlCommand cmdegzersiz778 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=12 AND (Kalori >=163 AND Kalori <=175)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                            SqlDataReader dregzersiz778 = cmdegzersiz778.ExecuteReader();

                            DataList4.DataSource = dregzersiz778;

                            DataList4.DataBind();

                            break;

                        case 9:

                            SqlCommand cmdegzersiz00 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=255 AND Kalori <=265) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=2  AND (Kalori >=50 AND Kalori <=60)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID()  ) AS T", baglan.baglan());

                            SqlDataReader dregzersiz00 = cmdegzersiz00.ExecuteReader();

                            DataList1.DataSource = dregzersiz00;

                            DataList1.DataBind();


                            SqlCommand cmdegzersiz01 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=7 AND (Kalori >=190 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=21 AND (Kalori >=210 AND Kalori <=230) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 8 AND(Kalori >= 65 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 120) ORDER BY NEWID()) AS K  ", baglan.baglan());

                            SqlDataReader dregzersiz01 = cmdegzersiz01.ExecuteReader();

                            DataList2.DataSource = dregzersiz01;

                            DataList2.DataBind();


                            SqlCommand cmdegzersiz02 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=7 AND (Kalori >=130 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=4 AND (Kalori >=100 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=15 AND (Kalori >=110 AND Kalori <=150) ORDER BY NEWID () ) AS K", baglan.baglan());

                            SqlDataReader dregzersiz02 = cmdegzersiz02.ExecuteReader();

                            DataList3.DataSource = dregzersiz02;

                            DataList3.DataBind();


                            SqlCommand cmdegzersiz03 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%"+i+"%' AND Besin_Category_ID=12 AND (Kalori >=160 AND Kalori <=200)  ORDER BY NEWID () ) AS K", baglan.baglan());

                            SqlDataReader dregzersiz03 = cmdegzersiz03.ExecuteReader();

                            DataList4.DataSource = dregzersiz03;

                            DataList4.DataBind();

                            break;
                    }



                



           

























            /////////////////////////////////////////////////////////////////

            /*  if (RadioButton1.Checked == true)
              {


                  if (Convert.ToInt32(TextBox1.Text) >= 1000 && Convert.ToInt32(TextBox1.Text) < 1200)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 5 and (Kalori >= 120 and Kalori <= 150) ORDER BY  NEWID()) AS T UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and (Kalori >= 130 and Kalori <= 140)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 30 and Kalori <= 45)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 2 and (Kalori >= 65 and Kalori <= 80)  ORDER BY  NEWID()) AS T   UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 17 and (Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()) AS T", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 3 AND (Kalori >= 55 AND Kalori <= 75)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 7 AND (Kalori >= 55 AND Kalori <= 80) ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 21 AND  (Kalori >= 200 AND Kalori <= 220) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 105)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 7 AND (Kalori >= 100 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 12 AND (Kalori >= 125 AND Kalori <= 150)  ORDER BY NEWID() ) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if (int.Parse(TextBox1.Text) >= 1200 && int.Parse(TextBox1.Text) < 1400)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 5 and (Kalori >= 150 and Kalori <= 180)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM (Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 150 and Kalori <= 160)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 35 and Kalori <= 50)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 2 and (Kalori >= 80 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION   SELECT *   FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 3 AND (Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 7 AND (Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand(" SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 95)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 55) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 12 AND(Kalori >= 150 AND Kalori <= 175)  ORDER BY NEWID() ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if ( int.Parse(TextBox1.Text) >= 1400 && int.Parse(TextBox1.Text) < 1600)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 5 and(Kalori >= 180 and Kalori <= 210)  ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 170 and Kalori <= 180) ORDER BY  NEWID()) AS T  UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 40 and Kalori <= 55)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 15 and Kalori <= 30)   ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 2 and(Kalori >= 80 and Kalori <= 95)   ORDER BY  NEWID()) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT *  FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like  '%7%' AND Besin_Category_ID = 3 AND(Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 7 AND(Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 8 AND(Kalori >= 0 AND Kalori <= 60) ORDER BY NEWID() ) AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 115) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 85) ORDER BY NEWID() ) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("select * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 12 AND(Kalori >= 175 AND Kalori <= 200)  ORDER BY NEWID() ) AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if ( int.Parse(TextBox1.Text) >= 1600 && int.Parse(TextBox1.Text) < 1800)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 5 and(Kalori >= 210 and Kalori <= 240)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 180 and Kalori <= 190)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 20 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 2 and(Kalori >= 85 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 11 AND(Kalori >= 30 AND Kalori <= 60) ORDER BY NEWID()) AS K", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=110 AND Kalori <=120)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=4 AND (Kalori >=70 AND Kalori <=85) ORDER BY NEWID ()) AS K", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=12 AND (Kalori >=100 AND Kalori <=112)  ORDER BY NEWID () ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if (int.Parse(TextBox1.Text) >= 1800 && int.Parse(TextBox1.Text) < 2000)
                  {
                      SqlCommand cmdegzersiz = new SqlCommand("SELECT *FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=5 AND (Kalori >=175 AND Kalori <=210)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=200 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=40 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=35)ORDER BY  NEWID() )AS T", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=140 AND Kalori <=150)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=135) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 90) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=12 AND (Kalori >=225 AND Kalori <=250)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if (int.Parse(TextBox1.Text) >= 2000 && int.Parse(TextBox1.Text) < 2200)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=5 AND (Kalori >=200 AND Kalori <=235)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=215 AND Kalori <=225) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=50 AND Kalori <=65) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T ", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID ()UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=175 AND Kalori <=190)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID () ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand(" SELECT *  FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=12 AND (Kalori >=125 AND Kalori <=138)  ORDER BY NEWID ()  ) AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if ( int.Parse(TextBox1.Text) >= 2200 && int.Parse(TextBox1.Text) < 2400)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=5 AND (Kalori >=225 AND Kalori <=260)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=60 AND Kalori <=75) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori  <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=21 AND (Kalori >=220 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 65) ORDER BY NEWID())AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=4 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 15 AND(Kalori >= 60 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=12 AND (Kalori >=138 AND Kalori <=150)  ORDER BY NEWID () ) AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if ( int.Parse(TextBox1.Text) >= 2400 && int.Parse(TextBox1.Text) < 2600)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=290)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 8 AND(Kalori >= 40 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND  Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 4 AND(Kalori >= 60 AND Kalori <= 85) ORDER BY NEWID()) AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=136 AND Kalori <=145) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 4 AND(Kalori >= 121 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 15 AND(Kalori >= 63 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=12 AND (Kalori >=150 AND Kalori <=165)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if (int.Parse(TextBox1.Text) >= 2600 && int.Parse(TextBox1.Text) < 2800)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=21 AND (Kalori >=240 AND Kalori <=260) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 8 AND(Kalori >= 45 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 115) ORDER BY NEWID()) AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=150 AND Kalori <=160)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=155 AND Kalori <=165) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=4 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID ()) AS K", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=12 AND (Kalori >=163 AND Kalori <=175)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if ( int.Parse(TextBox1.Text) >= 2800 && int.Parse(TextBox1.Text) < 3000)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=255 AND Kalori <=265) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=2  AND (Kalori >=50 AND Kalori <=60)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID()  ) AS T", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=190 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=21 AND (Kalori >=210 AND Kalori <=230) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 8 AND(Kalori >= 65 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 120) ORDER BY NEWID()) AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=130 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=4 AND (Kalori >=100 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=15 AND (Kalori >=110 AND Kalori <=150) ORDER BY NEWID () ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=12 AND (Kalori >=175 AND Kalori <=188)  ORDER BY NEWID () ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }
              }
 /*  if (RadioButton1.Checked == true)
            {


                if (Convert.ToInt32(TextBox1.Text) >= 1000 && Convert.ToInt32(TextBox1.Text) < 1200)
                {

                    SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 5 and (Kalori >= 120 and Kalori <= 150) ORDER BY  NEWID()) AS T UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and (Kalori >= 130 and Kalori <= 140)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 30 and Kalori <= 45)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 2 and (Kalori >= 65 and Kalori <= 80)  ORDER BY  NEWID()) AS T   UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 17 and (Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()) AS T", baglan.baglan());

                    SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                    DataList1.DataSource = dregzersiz;

                    DataList1.DataBind();


                    SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 3 AND (Kalori >= 55 AND Kalori <= 75)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 7 AND (Kalori >= 55 AND Kalori <= 80) ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 21 AND  (Kalori >= 200 AND Kalori <= 220) ORDER BY NEWID()) AS K ", baglan.baglan());

                    SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                    DataList2.DataSource = dregzersiz1;

                    DataList2.DataBind();


                    SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 105)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 7 AND (Kalori >= 100 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                    SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                    DataList3.DataSource = dregzersiz2;

                    DataList3.DataBind();


                    SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 12 AND (Kalori >= 125 AND Kalori <= 150)  ORDER BY NEWID() ) AS K ", baglan.baglan());

                    SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                    DataList4.DataSource = dregzersiz3;

                    DataList4.DataBind();

                }

                else if (int.Parse(TextBox1.Text) >= 1200 && int.Parse(TextBox1.Text) < 1400)
                {

                    SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 5 and (Kalori >= 150 and Kalori <= 180)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM (Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 150 and Kalori <= 160)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 35 and Kalori <= 50)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 2 and (Kalori >= 80 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION   SELECT *   FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                    SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                    DataList1.DataSource = dregzersiz;

                    DataList1.DataBind();


                    SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 3 AND (Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 7 AND (Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID()) AS K ", baglan.baglan());

                    SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                    DataList2.DataSource = dregzersiz1;

                    DataList2.DataBind();


                    SqlCommand cmdegzersiz2 = new SqlCommand(" SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 95)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 55) ORDER BY NEWID()) AS K ", baglan.baglan());

                    SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                    DataList3.DataSource = dregzersiz2;

                    DataList3.DataBind();


                    SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 12 AND(Kalori >= 150 AND Kalori <= 175)  ORDER BY NEWID() ) AS K", baglan.baglan());

                    SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                    DataList4.DataSource = dregzersiz3;

                    DataList4.DataBind();

                }

                else if ( int.Parse(TextBox1.Text) >= 1400 && int.Parse(TextBox1.Text) < 1600)
                {

                    SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 5 and(Kalori >= 180 and Kalori <= 210)  ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 170 and Kalori <= 180) ORDER BY  NEWID()) AS T  UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 40 and Kalori <= 55)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 15 and Kalori <= 30)   ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 2 and(Kalori >= 80 and Kalori <= 95)   ORDER BY  NEWID()) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                    SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                    DataList1.DataSource = dregzersiz;

                    DataList1.DataBind();


                    SqlCommand cmdegzersiz1 = new SqlCommand("SELECT *  FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like  '%7%' AND Besin_Category_ID = 3 AND(Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 7 AND(Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 8 AND(Kalori >= 0 AND Kalori <= 60) ORDER BY NEWID() ) AS K  ", baglan.baglan());

                    SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                    DataList2.DataSource = dregzersiz1;

                    DataList2.DataBind();


                    SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 115) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 85) ORDER BY NEWID() ) AS K ", baglan.baglan());

                    SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                    DataList3.DataSource = dregzersiz2;

                    DataList3.DataBind();


                    SqlCommand cmdegzersiz3 = new SqlCommand("select * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 12 AND(Kalori >= 175 AND Kalori <= 200)  ORDER BY NEWID() ) AS K  ", baglan.baglan());

                    SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                    DataList4.DataSource = dregzersiz3;

                    DataList4.DataBind();

                }

                else if ( int.Parse(TextBox1.Text) >= 1600 && int.Parse(TextBox1.Text) < 1800)
                {

                    SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 5 and(Kalori >= 210 and Kalori <= 240)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 180 and Kalori <= 190)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 1 and(Kalori >= 20 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '% 7%' AND Besin_Category_ID = 2 and(Kalori >= 85 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T", baglan.baglan());

                    SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                    DataList1.DataSource = dregzersiz;

                    DataList1.DataBind();


                    SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 11 AND(Kalori >= 30 AND Kalori <= 60) ORDER BY NEWID()) AS K", baglan.baglan());

                    SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                    DataList2.DataSource = dregzersiz1;

                    DataList2.DataBind();


                    SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=110 AND Kalori <=120)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=4 AND (Kalori >=70 AND Kalori <=85) ORDER BY NEWID ()) AS K", baglan.baglan());

                    SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                    DataList3.DataSource = dregzersiz2;

                    DataList3.DataBind();


                    SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=12 AND (Kalori >=100 AND Kalori <=112)  ORDER BY NEWID () ) AS K", baglan.baglan());

                    SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                    DataList4.DataSource = dregzersiz3;

                    DataList4.DataBind();

                }

                else if (int.Parse(TextBox1.Text) >= 1800 && int.Parse(TextBox1.Text) < 2000)
                {
                    SqlCommand cmdegzersiz = new SqlCommand("SELECT *FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=5 AND (Kalori >=175 AND Kalori <=210)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=200 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=40 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=35)ORDER BY  NEWID() )AS T", baglan.baglan());

                    SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                    DataList1.DataSource = dregzersiz;

                    DataList1.DataBind();


                    SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                    SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                    DataList2.DataSource = dregzersiz1;

                    DataList2.DataBind();


                    SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=140 AND Kalori <=150)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=135) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 90) ORDER BY NEWID()) AS K ", baglan.baglan());

                    SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                    DataList3.DataSource = dregzersiz2;

                    DataList3.DataBind();


                    SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=12 AND (Kalori >=225 AND Kalori <=250)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                    SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                    DataList4.DataSource = dregzersiz3;

                    DataList4.DataBind();

                }

                else if (int.Parse(TextBox1.Text) >= 2000 && int.Parse(TextBox1.Text) < 2200)
                {

                    SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=5 AND (Kalori >=200 AND Kalori <=235)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=215 AND Kalori <=225) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=50 AND Kalori <=65) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T ", baglan.baglan());

                    SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                    DataList1.DataSource = dregzersiz;

                    DataList1.DataBind();


                    SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID ()UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                    SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                    DataList2.DataSource = dregzersiz1;

                    DataList2.DataBind();


                    SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=175 AND Kalori <=190)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID () ) AS K", baglan.baglan());

                    SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                    DataList3.DataSource = dregzersiz2;

                    DataList3.DataBind();


                    SqlCommand cmdegzersiz3 = new SqlCommand(" SELECT *  FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=12 AND (Kalori >=125 AND Kalori <=138)  ORDER BY NEWID ()  ) AS K  ", baglan.baglan());

                    SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                    DataList4.DataSource = dregzersiz3;

                    DataList4.DataBind();

                }

                else if ( int.Parse(TextBox1.Text) >= 2200 && int.Parse(TextBox1.Text) < 2400)
                {

                    SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=5 AND (Kalori >=225 AND Kalori <=260)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=60 AND Kalori <=75) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori  <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                    SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                    DataList1.DataSource = dregzersiz;

                    DataList1.DataBind();


                    SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=21 AND (Kalori >=220 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 65) ORDER BY NEWID())AS K  ", baglan.baglan());

                    SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                    DataList2.DataSource = dregzersiz1;

                    DataList2.DataBind();


                    SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=4 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 15 AND(Kalori >= 60 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                    SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                    DataList3.DataSource = dregzersiz2;

                    DataList3.DataBind();


                    SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=12 AND (Kalori >=138 AND Kalori <=150)  ORDER BY NEWID () ) AS K  ", baglan.baglan());

                    SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                    DataList4.DataSource = dregzersiz3;

                    DataList4.DataBind();

                }

                else if ( int.Parse(TextBox1.Text) >= 2400 && int.Parse(TextBox1.Text) < 2600)
                {

                    SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=290)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                    SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                    DataList1.DataSource = dregzersiz;

                    DataList1.DataBind();


                    SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 8 AND(Kalori >= 40 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND  Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 4 AND(Kalori >= 60 AND Kalori <= 85) ORDER BY NEWID()) AS K  ", baglan.baglan());

                    SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                    DataList2.DataSource = dregzersiz1;

                    DataList2.DataBind();


                    SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=136 AND Kalori <=145) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 4 AND(Kalori >= 121 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 15 AND(Kalori >= 63 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                    SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                    DataList3.DataSource = dregzersiz2;

                    DataList3.DataBind();


                    SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=12 AND (Kalori >=150 AND Kalori <=165)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                    SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                    DataList4.DataSource = dregzersiz3;

                    DataList4.DataBind();

                }

                else if (int.Parse(TextBox1.Text) >= 2600 && int.Parse(TextBox1.Text) < 2800)
                {

                    SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                    SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                    DataList1.DataSource = dregzersiz;

                    DataList1.DataBind();


                    SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=21 AND (Kalori >=240 AND Kalori <=260) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 8 AND(Kalori >= 45 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 115) ORDER BY NEWID()) AS K  ", baglan.baglan());

                    SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                    DataList2.DataSource = dregzersiz1;

                    DataList2.DataBind();


                    SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=150 AND Kalori <=160)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=155 AND Kalori <=165) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=4 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID ()) AS K", baglan.baglan());

                    SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                    DataList3.DataSource = dregzersiz2;

                    DataList3.DataBind();


                    SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=12 AND (Kalori >=163 AND Kalori <=175)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                    SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                    DataList4.DataSource = dregzersiz3;

                    DataList4.DataBind();

                }

                else if ( int.Parse(TextBox1.Text) >= 2800 && int.Parse(TextBox1.Text) < 3000)
                {

                    SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=255 AND Kalori <=265) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=2  AND (Kalori >=50 AND Kalori <=60)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID()  ) AS T", baglan.baglan());

                    SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                    DataList1.DataSource = dregzersiz;

                    DataList1.DataBind();


                    SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=190 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=21 AND (Kalori >=210 AND Kalori <=230) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 8 AND(Kalori >= 65 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 120) ORDER BY NEWID()) AS K  ", baglan.baglan());

                    SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                    DataList2.DataSource = dregzersiz1;

                    DataList2.DataBind();


                    SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=7 AND (Kalori >=130 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=4 AND (Kalori >=100 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=15 AND (Kalori >=110 AND Kalori <=150) ORDER BY NEWID () ) AS K", baglan.baglan());

                    SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                    DataList3.DataSource = dregzersiz2;

                    DataList3.DataBind();


                    SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%7%' AND Besin_Category_ID=12 AND (Kalori >=175 AND Kalori <=188)  ORDER BY NEWID () ) AS K", baglan.baglan());

                    SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                    DataList4.DataSource = dregzersiz3;

                    DataList4.DataBind();

                }
            }


              if (RadioButton2.Checked == true)
              {
                  if (Convert.ToInt32(TextBox1.Text) >= 1000 && Convert.ToInt32(TextBox1.Text) < 1200)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 5 and (Kalori >= 120 and Kalori <= 150) ORDER BY  NEWID()) AS T UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 1 and (Kalori >= 130 and Kalori <= 140)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 1 and(Kalori >= 30 and Kalori <= 45)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 2 and (Kalori >= 65 and Kalori <= 80)  ORDER BY  NEWID()) AS T   UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 17 and (Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()) AS T", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 3 AND (Kalori >= 55 AND Kalori <= 75)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 1 AND (Kalori >= 55 AND Kalori <= 80) ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '% 1%' AND Besin_Category_ID = 21 AND  (Kalori >= 200 AND Kalori <= 220) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 105)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 7 AND (Kalori >= 100 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 12 AND (Kalori >= 125 AND Kalori <= 150)  ORDER BY NEWID() ) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if (int.Parse(TextBox1.Text) >= 1200 && int.Parse(TextBox1.Text) < 1400)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 5 and (Kalori >= 150 and Kalori <= 180)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM (Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 1 and(Kalori >= 150 and Kalori <= 160)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 1 and(Kalori >= 35 and Kalori <= 50)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 2 and (Kalori >= 80 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION   SELECT *   FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 3 AND (Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 1 AND (Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand(" SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 95)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 55) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 12 AND(Kalori >= 150 AND Kalori <= 175)  ORDER BY NEWID() ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if (int.Parse(TextBox1.Text) >= 1400 && int.Parse(TextBox1.Text) < 1600)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 5 and(Kalori >= 180 and Kalori <= 210)  ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 1 and(Kalori >= 170 and Kalori <= 180) ORDER BY  NEWID()) AS T  UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 1 and(Kalori >= 40 and Kalori <= 55)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 1 and(Kalori >= 15 and Kalori <= 30)   ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 2 and(Kalori >= 80 and Kalori <= 95)   ORDER BY  NEWID()) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT *  FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like  '%1%' AND Besin_Category_ID = 3 AND(Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 7 AND(Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 8 AND(Kalori >= 0 AND Kalori <= 60) ORDER BY NEWID() ) AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 115) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 85) ORDER BY NEWID() ) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("select * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 12 AND(Kalori >= 175 AND Kalori <= 200)  ORDER BY NEWID() ) AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if (int.Parse(TextBox1.Text) >= 1600 && int.Parse(TextBox1.Text) < 1800)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 5 and(Kalori >= 210 and Kalori <= 240)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 1 and(Kalori >= 180 and Kalori <= 190)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 1 and(Kalori >= 20 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '% 1%' AND Besin_Category_ID = 2 and(Kalori >= 85 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 11 AND(Kalori >= 30 AND Kalori <= 60) ORDER BY NEWID()) AS K", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;
                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=3 AND (Kalori >=110 AND Kalori <=120)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=4 AND (Kalori >=70 AND Kalori <=85) ORDER BY NEWID ()) AS K", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=12 AND (Kalori >=100 AND Kalori <=112)  ORDER BY NEWID () ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if (int.Parse(TextBox1.Text) >= 1800 && int.Parse(TextBox1.Text) < 2000)
                  {
                      SqlCommand cmdegzersiz = new SqlCommand("SELECT *FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=5 AND (Kalori >=175 AND Kalori <=210)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=200 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=40 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=35)ORDER BY  NEWID() )AS T", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=3 AND (Kalori >=140 AND Kalori <=150)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=135) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 90) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=12 AND (Kalori >=225 AND Kalori <=250)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if (int.Parse(TextBox1.Text) >= 2000 && int.Parse(TextBox1.Text) < 2200)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=5 AND (Kalori >=200 AND Kalori <=235)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=215 AND Kalori <=225) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=50 AND Kalori <=65) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T ", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();





                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID ()UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=3 AND (Kalori >=175 AND Kalori <=190)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID () ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand(" SELECT *  FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=12 AND (Kalori >=125 AND Kalori <=138)  ORDER BY NEWID ()  ) AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if  (int.Parse(TextBox1.Text) >= 2200 && int.Parse(TextBox1.Text) < 2400)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=5 AND (Kalori >=225 AND Kalori <=260)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=60 AND Kalori <=75) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori  <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=21 AND (Kalori >=220 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 65) ORDER BY NEWID())AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=7 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=4 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 15 AND(Kalori >= 60 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=12 AND (Kalori >=138 AND Kalori <=150)  ORDER BY NEWID () ) AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if  (int.Parse(TextBox1.Text) >= 2400 && int.Parse(TextBox1.Text) < 2600)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=290)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 8 AND(Kalori >= 40 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND  Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 4 AND(Kalori >= 60 AND Kalori <= 85) ORDER BY NEWID()) AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=7 AND (Kalori >=136 AND Kalori <=145) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 4 AND(Kalori >= 121 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 15 AND(Kalori >= 63 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=12 AND (Kalori >=150 AND Kalori <=165)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if  (int.Parse(TextBox1.Text) >= 2600 && int.Parse(TextBox1.Text) < 2800)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=21 AND (Kalori >=240 AND Kalori <=260) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 8 AND(Kalori >= 45 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 115) ORDER BY NEWID()) AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=3 AND (Kalori >=150 AND Kalori <=160)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=7 AND (Kalori >=155 AND Kalori <=165) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=4 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID ()) AS K", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=12 AND (Kalori >=163 AND Kalori <=175)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }

                  else if  (int.Parse(TextBox1.Text) >= 2800 && int.Parse(TextBox1.Text) < 3000)
                  {

                      SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=255 AND Kalori <=265) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=2  AND (Kalori >=50 AND Kalori <=60)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID()  ) AS T", baglan.baglan());

                      SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                      DataList1.DataSource = dregzersiz;

                      DataList1.DataBind();


                      SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=7 AND (Kalori >=190 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=21 AND (Kalori >=210 AND Kalori <=230) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 8 AND(Kalori >= 65 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 120) ORDER BY NEWID()) AS K  ", baglan.baglan());

                      SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                      DataList2.DataSource = dregzersiz1;

                      DataList2.DataBind();


                      SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=7 AND (Kalori >=130 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=4 AND (Kalori >=100 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=15 AND (Kalori >=110 AND Kalori <=150) ORDER BY NEWID () ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                      DataList3.DataSource = dregzersiz2;

                      DataList3.DataBind();


                      SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%1%' AND Besin_Category_ID=12 AND (Kalori >=175 AND Kalori <=188)  ORDER BY NEWID () ) AS K", baglan.baglan());

                      SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                      DataList4.DataSource = dregzersiz3;

                      DataList4.DataBind();

                  }
              }

              if (RadioButton3.Checked == true && Convert.ToInt32(TextBox1.Text) >= 1000 && Convert.ToInt32(TextBox1.Text) < 1200)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 5 and (Kalori >= 120 and Kalori <= 150) ORDER BY  NEWID()) AS T UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 1 and (Kalori >= 130 and Kalori <= 140)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 1 and(Kalori >= 30 and Kalori <= 45)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 2 and (Kalori >= 65 and Kalori <= 80)  ORDER BY  NEWID()) AS T   UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 17 and (Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 3 AND (Kalori >= 55 AND Kalori <= 75)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 7 AND (Kalori >= 55 AND Kalori <= 80) ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 21 AND  (Kalori >= 200 AND Kalori <= 220) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 105)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 7 AND (Kalori >= 100 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 12 AND (Kalori >= 125 AND Kalori <= 150)  ORDER BY NEWID() ) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton3.Checked == true && int.Parse(TextBox1.Text) >= 1200 && int.Parse(TextBox1.Text) < 1400)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 5 and (Kalori >= 150 and Kalori <= 180)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM (Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 1 and(Kalori >= 150 and Kalori <= 160)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 1 and(Kalori >= 35 and Kalori <= 50)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 2 and (Kalori >= 80 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION   SELECT *   FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 3 AND (Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 7 AND (Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand(" SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 95)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 55) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 12 AND(Kalori >= 150 AND Kalori <= 175)  ORDER BY NEWID() ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton3.Checked == true && int.Parse(TextBox1.Text) >= 1400 && int.Parse(TextBox1.Text) < 1600)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 5 and(Kalori >= 180 and Kalori <= 210)  ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 1 and(Kalori >= 170 and Kalori <= 180) ORDER BY  NEWID()) AS T  UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 1 and(Kalori >= 40 and Kalori <= 55)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 1 and(Kalori >= 15 and Kalori <= 30)   ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 2 and(Kalori >= 80 and Kalori <= 95)   ORDER BY  NEWID()) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT *  FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like  '%2%' AND Besin_Category_ID = 3 AND(Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 7 AND(Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 8 AND(Kalori >= 0 AND Kalori <= 60) ORDER BY NEWID() ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 115) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 85) ORDER BY NEWID() ) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("select * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 12 AND(Kalori >= 175 AND Kalori <= 200)  ORDER BY NEWID() ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton3.Checked == true && int.Parse(TextBox1.Text) >= 1600 && int.Parse(TextBox1.Text) < 1800)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 5 and(Kalori >= 210 and Kalori <= 240)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 1 and(Kalori >= 180 and Kalori <= 190)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 1 and(Kalori >= 20 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 2 and(Kalori >= 85 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 11 AND(Kalori >= 30 AND Kalori <= 60) ORDER BY NEWID()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=3 AND (Kalori >=110 AND Kalori <=120)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=4 AND (Kalori >=70 AND Kalori <=85) ORDER BY NEWID ()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=12 AND (Kalori >=100 AND Kalori <=112)  ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton3.Checked == true && int.Parse(TextBox1.Text) >= 1800 && int.Parse(TextBox1.Text) < 2000)
              {
                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=5 AND (Kalori >=175 AND Kalori <=210)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=200 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=40 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=35)ORDER BY  NEWID() )AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=3 AND (Kalori >=140 AND Kalori <=150)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=135) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 90) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=12 AND (Kalori >=225 AND Kalori <=250)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton3.Checked == true && int.Parse(TextBox1.Text) >= 2000 && int.Parse(TextBox1.Text) < 2200)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=5 AND (Kalori >=200 AND Kalori <=235)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=215 AND Kalori <=225) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=50 AND Kalori <=65) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID ()UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=3 AND (Kalori >=175 AND Kalori <=190)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand(" SELECT *  FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=12 AND (Kalori >=125 AND Kalori <=138)  ORDER BY NEWID ()  ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton3.Checked == true && int.Parse(TextBox1.Text) >= 2200 && int.Parse(TextBox1.Text) < 2400)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=5 AND (Kalori >=225 AND Kalori <=260)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=60 AND Kalori <=75) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori  <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=21 AND (Kalori >=220 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 65) ORDER BY NEWID())AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=7 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=4 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 15 AND(Kalori >= 60 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=12 AND (Kalori >=138 AND Kalori <=150)  ORDER BY NEWID () ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton3.Checked == true && int.Parse(TextBox1.Text) >= 2400 && int.Parse(TextBox1.Text) < 2600)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=290)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 8 AND(Kalori >= 40 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND  Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 4 AND(Kalori >= 60 AND Kalori <= 85) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=7 AND (Kalori >=136 AND Kalori <=145) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 4 AND(Kalori >= 121 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 15 AND(Kalori >= 63 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=12 AND (Kalori >=150 AND Kalori <=165)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton3.Checked == true && int.Parse(TextBox1.Text) >= 2600 && int.Parse(TextBox1.Text) < 2800)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=21 AND (Kalori >=240 AND Kalori <=260) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 8 AND(Kalori >= 45 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 115) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=3 AND (Kalori >=150 AND Kalori <=160)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=7 AND (Kalori >=155 AND Kalori <=165) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=4 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID ()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=12 AND (Kalori >=163 AND Kalori <=175)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton3.Checked == true && int.Parse(TextBox1.Text) >= 2800 && int.Parse(TextBox1.Text) < 3000)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=255 AND Kalori <=265) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=2  AND (Kalori >=50 AND Kalori <=60)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID()  ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=7 AND (Kalori >=190 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=21 AND (Kalori >=210 AND Kalori <=230) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 8 AND(Kalori >= 65 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 120) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=7 AND (Kalori >=130 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=4 AND (Kalori >=100 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=15 AND (Kalori >=110 AND Kalori <=150) ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%2%' AND Besin_Category_ID=12 AND (Kalori >=175 AND Kalori <=188)  ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }


              if (RadioButton4.Checked == true && Convert.ToInt32(TextBox1.Text) >= 1000 && Convert.ToInt32(TextBox1.Text) < 1200)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 5 and (Kalori >= 120 and Kalori <= 150) ORDER BY  NEWID()) AS T UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 1 and (Kalori >= 130 and Kalori <= 140)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 1 and(Kalori >= 30 and Kalori <= 45)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 2 and (Kalori >= 65 and Kalori <= 80)  ORDER BY  NEWID()) AS T   UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 17 and (Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 3 AND (Kalori >= 55 AND Kalori <= 75)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 7 AND (Kalori >= 55 AND Kalori <= 80) ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 21 AND  (Kalori >= 200 AND Kalori <= 220) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 105)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 7 AND (Kalori >= 100 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 12 AND (Kalori >= 125 AND Kalori <= 150)  ORDER BY NEWID() ) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton4.Checked == true && int.Parse(TextBox1.Text) >= 1200 && int.Parse(TextBox1.Text) < 1400)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 5 and (Kalori >= 150 and Kalori <= 180)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM (Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 1 and(Kalori >= 150 and Kalori <= 160)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 1 and(Kalori >= 35 and Kalori <= 50)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 2 and (Kalori >= 80 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION   SELECT *   FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 3 AND (Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 7 AND (Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand(" SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 95)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 55) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 12 AND(Kalori >= 150 AND Kalori <= 175)  ORDER BY NEWID() ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton4.Checked == true && int.Parse(TextBox1.Text) >= 1400 && int.Parse(TextBox1.Text) < 1600)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 5 and(Kalori >= 180 and Kalori <= 210)  ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 1 and(Kalori >= 170 and Kalori <= 180) ORDER BY  NEWID()) AS T  UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 1 and(Kalori >= 40 and Kalori <= 55)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 1 and(Kalori >= 15 and Kalori <= 30)   ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 2 and(Kalori >= 80 and Kalori <= 95)   ORDER BY  NEWID()) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT *  FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like  '%3%' AND Besin_Category_ID = 3 AND(Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 7 AND(Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 8 AND(Kalori >= 0 AND Kalori <= 60) ORDER BY NEWID() ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 115) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 85) ORDER BY NEWID() ) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("select * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 12 AND(Kalori >= 175 AND Kalori <= 200)  ORDER BY NEWID() ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton4.Checked == true && int.Parse(TextBox1.Text) >= 1600 && int.Parse(TextBox1.Text) < 1800)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 5 and(Kalori >= 210 and Kalori <= 240)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 1 and(Kalori >= 180 and Kalori <= 190)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 1 and(Kalori >= 20 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 2 and(Kalori >= 85 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 11 AND(Kalori >= 30 AND Kalori <= 60) ORDER BY NEWID()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=3 AND (Kalori >=110 AND Kalori <=120)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=4 AND (Kalori >=70 AND Kalori <=85) ORDER BY NEWID ()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=12 AND (Kalori >=100 AND Kalori <=112)  ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton4.Checked == true && int.Parse(TextBox1.Text) >= 1800 && int.Parse(TextBox1.Text) < 2000)
              {
                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=5 AND (Kalori >=175 AND Kalori <=210)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=200 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=40 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=35)ORDER BY  NEWID() )AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=3 AND (Kalori >=140 AND Kalori <=150)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=135) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 90) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=12 AND (Kalori >=225 AND Kalori <=250)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton4.Checked == true && int.Parse(TextBox1.Text) >= 2000 && int.Parse(TextBox1.Text) < 2200)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=5 AND (Kalori >=200 AND Kalori <=235)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=215 AND Kalori <=225) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=50 AND Kalori <=65) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID ()UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=3 AND (Kalori >=175 AND Kalori <=190)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand(" SELECT *  FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=12 AND (Kalori >=125 AND Kalori <=138)  ORDER BY NEWID ()  ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton4.Checked == true && int.Parse(TextBox1.Text) >= 2200 && int.Parse(TextBox1.Text) < 2400)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=5 AND (Kalori >=225 AND Kalori <=260)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=60 AND Kalori <=75) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori  <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=21 AND (Kalori >=220 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 65) ORDER BY NEWID())AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=7 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=4 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 15 AND(Kalori >= 60 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=12 AND (Kalori >=138 AND Kalori <=150)  ORDER BY NEWID () ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton4.Checked == true && int.Parse(TextBox1.Text) >= 2400 && int.Parse(TextBox1.Text) < 2600)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=290)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 8 AND(Kalori >= 40 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND  Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 4 AND(Kalori >= 60 AND Kalori <= 85) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=7 AND (Kalori >=136 AND Kalori <=145) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 4 AND(Kalori >= 121 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 15 AND(Kalori >= 63 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=12 AND (Kalori >=150 AND Kalori <=165)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton4.Checked == true && int.Parse(TextBox1.Text) >= 2600 && int.Parse(TextBox1.Text) < 2800)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=21 AND (Kalori >=240 AND Kalori <=260) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 8 AND(Kalori >= 45 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 115) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=3 AND (Kalori >=150 AND Kalori <=160)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=7 AND (Kalori >=155 AND Kalori <=165) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=4 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID ()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=12 AND (Kalori >=163 AND Kalori <=175)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton4.Checked == true && int.Parse(TextBox1.Text) >= 2800 && int.Parse(TextBox1.Text) < 3000)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=255 AND Kalori <=265) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=2  AND (Kalori >=50 AND Kalori <=60)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID()  ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=7 AND (Kalori >=190 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=21 AND (Kalori >=210 AND Kalori <=230) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 8 AND(Kalori >= 65 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 120) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=7 AND (Kalori >=130 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=4 AND (Kalori >=100 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=15 AND (Kalori >=110 AND Kalori <=150) ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%3%' AND Besin_Category_ID=12 AND (Kalori >=175 AND Kalori <=188)  ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }


              if (RadioButton5.Checked == true && Convert.ToInt32(TextBox1.Text) >= 1000 && Convert.ToInt32(TextBox1.Text) < 1200)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 5 and (Kalori >= 120 and Kalori <= 150) ORDER BY  NEWID()) AS T UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 1 and (Kalori >= 130 and Kalori <= 140)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 1 and(Kalori >= 30 and Kalori <= 45)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 2 and (Kalori >= 65 and Kalori <= 80)  ORDER BY  NEWID()) AS T   UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 17 and (Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 3 AND (Kalori >= 55 AND Kalori <= 75)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 7 AND (Kalori >= 55 AND Kalori <= 80) ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 21 AND  (Kalori >= 200 AND Kalori <= 220) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 105)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 7 AND (Kalori >= 100 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 12 AND (Kalori >= 125 AND Kalori <= 150)  ORDER BY NEWID() ) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton5.Checked == true && int.Parse(TextBox1.Text) >= 1200 && int.Parse(TextBox1.Text) < 1400)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 5 and (Kalori >= 150 and Kalori <= 180)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM (Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 1 and(Kalori >= 150 and Kalori <= 160)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 1 and(Kalori >= 35 and Kalori <= 50)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 2 and (Kalori >= 80 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION   SELECT *   FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 3 AND (Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 7 AND (Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand(" SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 95)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 55) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 12 AND(Kalori >= 150 AND Kalori <= 175)  ORDER BY NEWID() ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton5.Checked == true && int.Parse(TextBox1.Text) >= 1400 && int.Parse(TextBox1.Text) < 1600)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 5 and(Kalori >= 180 and Kalori <= 210)  ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 1 and(Kalori >= 170 and Kalori <= 180) ORDER BY  NEWID()) AS T  UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 1 and(Kalori >= 40 and Kalori <= 55)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 1 and(Kalori >= 15 and Kalori <= 30)   ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 2 and(Kalori >= 80 and Kalori <= 95)   ORDER BY  NEWID()) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT *  FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like  '%4%' AND Besin_Category_ID = 3 AND(Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 7 AND(Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 8 AND(Kalori >= 0 AND Kalori <= 60) ORDER BY NEWID() ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 115) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 85) ORDER BY NEWID() ) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("select * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 12 AND(Kalori >= 175 AND Kalori <= 200)  ORDER BY NEWID() ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton5.Checked == true && int.Parse(TextBox1.Text) >= 1600 && int.Parse(TextBox1.Text) < 1800)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 5 and(Kalori >= 210 and Kalori <= 240)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 1 and(Kalori >= 180 and Kalori <= 190)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 1 and(Kalori >= 20 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 2 and(Kalori >= 85 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 11 AND(Kalori >= 30 AND Kalori <= 60) ORDER BY NEWID()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=3 AND (Kalori >=110 AND Kalori <=120)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=4 AND (Kalori >=70 AND Kalori <=85) ORDER BY NEWID ()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=12 AND (Kalori >=100 AND Kalori <=112)  ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton5.Checked == true && int.Parse(TextBox1.Text) >= 1800 && int.Parse(TextBox1.Text) < 2000)
              {
                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=5 AND (Kalori >=175 AND Kalori <=210)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=200 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=40 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=35)ORDER BY  NEWID() )AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=3 AND (Kalori >=140 AND Kalori <=150)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=135) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 90) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=12 AND (Kalori >=225 AND Kalori <=250)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton5.Checked == true && int.Parse(TextBox1.Text) >= 2000 && int.Parse(TextBox1.Text) < 2200)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=5 AND (Kalori >=200 AND Kalori <=235)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=215 AND Kalori <=225) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=50 AND Kalori <=65) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID ()UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=3 AND (Kalori >=175 AND Kalori <=190)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand(" SELECT *  FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=12 AND (Kalori >=125 AND Kalori <=138)  ORDER BY NEWID ()  ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton5.Checked == true && int.Parse(TextBox1.Text) >= 2200 && int.Parse(TextBox1.Text) < 2400)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=5 AND (Kalori >=225 AND Kalori <=260)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=60 AND Kalori <=75) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori  <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=21 AND (Kalori >=220 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 65) ORDER BY NEWID())AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=7 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=4 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 15 AND(Kalori >= 60 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=12 AND (Kalori >=138 AND Kalori <=150)  ORDER BY NEWID () ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton5.Checked == true && int.Parse(TextBox1.Text) >= 2400 && int.Parse(TextBox1.Text) < 2600)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=290)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 8 AND(Kalori >= 40 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND  Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 4 AND(Kalori >= 60 AND Kalori <= 85) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=7 AND (Kalori >=136 AND Kalori <=145) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 4 AND(Kalori >= 121 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 15 AND(Kalori >= 63 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=12 AND (Kalori >=150 AND Kalori <=165)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton5.Checked == true && int.Parse(TextBox1.Text) >= 2600 && int.Parse(TextBox1.Text) < 2800)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=21 AND (Kalori >=240 AND Kalori <=260) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 8 AND(Kalori >= 45 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 115) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=3 AND (Kalori >=150 AND Kalori <=160)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=7 AND (Kalori >=155 AND Kalori <=165) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=4 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID ()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=12 AND (Kalori >=163 AND Kalori <=175)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton5.Checked == true && int.Parse(TextBox1.Text) >= 2800 && int.Parse(TextBox1.Text) < 3000)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=255 AND Kalori <=265) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=2  AND (Kalori >=50 AND Kalori <=60)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID()  ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=7 AND (Kalori >=190 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=21 AND (Kalori >=210 AND Kalori <=230) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 8 AND(Kalori >= 65 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 120) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=7 AND (Kalori >=130 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=4 AND (Kalori >=100 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=15 AND (Kalori >=110 AND Kalori <=150) ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%4%' AND Besin_Category_ID=12 AND (Kalori >=175 AND Kalori <=188)  ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }


              if (RadioButton6.Checked == true && Convert.ToInt32(TextBox1.Text) >= 1000 && Convert.ToInt32(TextBox1.Text) < 1200)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 5 and (Kalori >= 120 and Kalori <= 150) ORDER BY  NEWID()) AS T UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 1 and (Kalori >= 130 and Kalori <= 140)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 1 and(Kalori >= 30 and Kalori <= 45)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 2 and (Kalori >= 65 and Kalori <= 80)  ORDER BY  NEWID()) AS T   UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 17 and (Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 3 AND (Kalori >= 55 AND Kalori <= 75)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 7 AND (Kalori >= 55 AND Kalori <= 80) ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 21 AND  (Kalori >= 200 AND Kalori <= 220) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 105)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 7 AND (Kalori >= 100 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 12 AND (Kalori >= 125 AND Kalori <= 150)  ORDER BY NEWID() ) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton6.Checked == true && int.Parse(TextBox1.Text) >= 1200 && int.Parse(TextBox1.Text) < 1400)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 5 and (Kalori >= 150 and Kalori <= 180)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM (Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 1 and(Kalori >= 150 and Kalori <= 160)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 1 and(Kalori >= 35 and Kalori <= 50)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 2 and (Kalori >= 80 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION   SELECT *   FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 3 AND (Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 7 AND (Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand(" SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 95)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 55) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 12 AND(Kalori >= 150 AND Kalori <= 175)  ORDER BY NEWID() ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton6.Checked == true && int.Parse(TextBox1.Text) >= 1400 && int.Parse(TextBox1.Text) < 1600)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 5 and(Kalori >= 180 and Kalori <= 210)  ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 1 and(Kalori >= 170 and Kalori <= 180) ORDER BY  NEWID()) AS T  UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 1 and(Kalori >= 40 and Kalori <= 55)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 1 and(Kalori >= 15 and Kalori <= 30)   ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 2 and(Kalori >= 80 and Kalori <= 95)   ORDER BY  NEWID()) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT *  FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like  '%5%' AND Besin_Category_ID = 3 AND(Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 7 AND(Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 8 AND(Kalori >= 0 AND Kalori <= 60) ORDER BY NEWID() ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 115) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 85) ORDER BY NEWID() ) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("select * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 12 AND(Kalori >= 175 AND Kalori <= 200)  ORDER BY NEWID() ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton6.Checked == true && int.Parse(TextBox1.Text) >= 1600 && int.Parse(TextBox1.Text) < 1800)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 5 and(Kalori >= 210 and Kalori <= 240)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 1 and(Kalori >= 180 and Kalori <= 190)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 1 and(Kalori >= 20 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 2 and(Kalori >= 85 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 11 AND(Kalori >= 30 AND Kalori <= 60) ORDER BY NEWID()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=3 AND (Kalori >=110 AND Kalori <=120)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=4 AND (Kalori >=70 AND Kalori <=85) ORDER BY NEWID ()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=12 AND (Kalori >=100 AND Kalori <=112)  ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton6.Checked == true && int.Parse(TextBox1.Text) >= 1800 && int.Parse(TextBox1.Text) < 2000)
              {
                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=5 AND (Kalori >=175 AND Kalori <=210)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=200 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=40 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=35)ORDER BY  NEWID() )AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=3 AND (Kalori >=140 AND Kalori <=150)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=135) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 90) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=12 AND (Kalori >=225 AND Kalori <=250)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton6.Checked == true && int.Parse(TextBox1.Text) >= 2000 && int.Parse(TextBox1.Text) < 2200)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=5 AND (Kalori >=200 AND Kalori <=235)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=215 AND Kalori <=225) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=50 AND Kalori <=65) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID ()UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=3 AND (Kalori >=175 AND Kalori <=190)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand(" SELECT *  FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=12 AND (Kalori >=125 AND Kalori <=138)  ORDER BY NEWID ()  ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton6.Checked == true && int.Parse(TextBox1.Text) >= 2200 && int.Parse(TextBox1.Text) < 2400)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=5 AND (Kalori >=225 AND Kalori <=260)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=60 AND Kalori <=75) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori  <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=21 AND (Kalori >=220 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 65) ORDER BY NEWID())AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=7 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=4 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 15 AND(Kalori >= 60 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=12 AND (Kalori >=138 AND Kalori <=150)  ORDER BY NEWID () ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton6.Checked == true && int.Parse(TextBox1.Text) >= 2400 && int.Parse(TextBox1.Text) < 2600)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=290)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 8 AND(Kalori >= 40 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND  Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 4 AND(Kalori >= 60 AND Kalori <= 85) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=7 AND (Kalori >=136 AND Kalori <=145) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 4 AND(Kalori >= 121 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 15 AND(Kalori >= 63 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=12 AND (Kalori >=150 AND Kalori <=165)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton6.Checked == true && int.Parse(TextBox1.Text) >= 2600 && int.Parse(TextBox1.Text) < 2800)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=21 AND (Kalori >=240 AND Kalori <=260) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 8 AND(Kalori >= 45 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 115) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=3 AND (Kalori >=150 AND Kalori <=160)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=7 AND (Kalori >=155 AND Kalori <=165) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=4 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID ()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=12 AND (Kalori >=163 AND Kalori <=175)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton6.Checked == true && int.Parse(TextBox1.Text) >= 2800 && int.Parse(TextBox1.Text) < 3000)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=255 AND Kalori <=265) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=2  AND (Kalori >=50 AND Kalori <=60)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID()  ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=7 AND (Kalori >=190 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=21 AND (Kalori >=210 AND Kalori <=230) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 8 AND(Kalori >= 65 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 120) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=7 AND (Kalori >=130 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=4 AND (Kalori >=100 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=15 AND (Kalori >=110 AND Kalori <=150) ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%5%' AND Besin_Category_ID=12 AND (Kalori >=175 AND Kalori <=188)  ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }


              if (RadioButton7.Checked == true && Convert.ToInt32(TextBox1.Text) >= 1000 && Convert.ToInt32(TextBox1.Text) < 1200)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 5 and (Kalori >= 120 and Kalori <= 150) ORDER BY  NEWID()) AS T UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 1 and (Kalori >= 130 and Kalori <= 140)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 1 and(Kalori >= 30 and Kalori <= 45)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 2 and (Kalori >= 65 and Kalori <= 80)  ORDER BY  NEWID()) AS T   UNION  SELECT *  FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 17 and (Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 3 AND (Kalori >= 55 AND Kalori <= 75)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 7 AND (Kalori >= 55 AND Kalori <= 80) ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 21 AND  (Kalori >= 200 AND Kalori <= 220) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 105)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 7 AND (Kalori >= 100 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM (SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 12 AND (Kalori >= 125 AND Kalori <= 150)  ORDER BY NEWID() ) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton7.Checked == true && int.Parse(TextBox1.Text) >= 1200 && int.Parse(TextBox1.Text) < 1400)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 5 and (Kalori >= 150 and Kalori <= 180)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM (Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 1 and(Kalori >= 150 and Kalori <= 160)  ORDER BY  NEWID()  ) AS T  UNION SELECT *   FROM(Select TOP(2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 1 and(Kalori >= 35 and Kalori <= 50)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 2 and (Kalori >= 80 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION   SELECT *   FROM (Select TOP(1) * from [Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 3 AND (Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 7 AND (Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand(" SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 95)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 55) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 12 AND(Kalori >= 150 AND Kalori <= 175)  ORDER BY NEWID() ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton7.Checked == true && int.Parse(TextBox1.Text) >= 1400 && int.Parse(TextBox1.Text) < 1600)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 5 and(Kalori >= 180 and Kalori <= 210)  ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 1 and(Kalori >= 170 and Kalori <= 180) ORDER BY  NEWID()) AS T  UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 1 and(Kalori >= 40 and Kalori <= 55)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 1 and(Kalori >= 15 and Kalori <= 30)   ORDER BY  NEWID()) AS T  UNION  SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 2 and(Kalori >= 80 and Kalori <= 95)   ORDER BY  NEWID()) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 2000)  ORDER BY  NEWID()  ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT *  FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like  '%6%' AND Besin_Category_ID = 3 AND(Kalori >= 75 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 7 AND(Kalori >= 80 AND Kalori <= 100) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 8 AND(Kalori >= 0 AND Kalori <= 60) ORDER BY NEWID() ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM(SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 3 AND(Kalori >= 85 AND Kalori <= 100)  ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 7 AND(Kalori >= 100 AND Kalori <= 115) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 85) ORDER BY NEWID() ) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("select * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 12 AND(Kalori >= 175 AND Kalori <= 200)  ORDER BY NEWID() ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton7.Checked == true && int.Parse(TextBox1.Text) >= 1600 && int.Parse(TextBox1.Text) < 1800)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]   WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 5 and(Kalori >= 210 and Kalori <= 240)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 1 and(Kalori >= 180 and Kalori <= 190)  ORDER BY  NEWID()  ) AS T   UNION SELECT *   FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 1 and(Kalori >= 20 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T UNION SELECT * FROM(Select TOP(2) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 2 and(Kalori >= 85 and Kalori <= 95)  ORDER BY  NEWID()  ) AS T   UNION  SELECT *   FROM(Select TOP(1) * from[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 17 and(Kalori >= 0 and Kalori <= 30)  ORDER BY  NEWID()  ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 11 AND(Kalori >= 30 AND Kalori <= 60) ORDER BY NEWID()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=3 AND (Kalori >=110 AND Kalori <=120)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=4 AND (Kalori >=70 AND Kalori <=85) ORDER BY NEWID ()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=12 AND (Kalori >=100 AND Kalori <=112)  ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton7.Checked == true && int.Parse(TextBox1.Text) >= 1800 && int.Parse(TextBox1.Text) < 2000)
              {
                  SqlCommand cmdegzersiz = new SqlCommand("SELECT *FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=5 AND (Kalori >=175 AND Kalori <=210)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=200 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=40 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=35)ORDER BY  NEWID() )AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand(" SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=100)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=7 AND (Kalori >=80 AND Kalori <=100) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=3 AND (Kalori >=140 AND Kalori <=150)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=7 AND (Kalori >=120 AND Kalori <=135) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 4 AND(Kalori >= 75 AND Kalori <= 90) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=12 AND (Kalori >=225 AND Kalori <=250)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton7.Checked == true && int.Parse(TextBox1.Text) >= 2000 && int.Parse(TextBox1.Text) < 2200)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=5 AND (Kalori >=200 AND Kalori <=235)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=215 AND Kalori <=225) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=50 AND Kalori <=65) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=2  AND (Kalori >=30 AND Kalori <=50)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T ", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID ()UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=21 AND (Kalori >=230 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=8 AND (Kalori >=10 AND Kalori <=60) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=3 AND (Kalori >=175 AND Kalori <=190)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand(" SELECT *  FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=12 AND (Kalori >=125 AND Kalori <=138)  ORDER BY NEWID ()  ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton7.Checked == true && int.Parse(TextBox1.Text) >= 2200 && int.Parse(TextBox1.Text) < 2400)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=5 AND (Kalori >=225 AND Kalori <=260)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=60 AND Kalori <=75) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori  <=500)ORDER BY  NEWID()  UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=3 AND (Kalori >=85 AND Kalori <=105)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=21 AND (Kalori >=220 AND Kalori <=240) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 8 AND(Kalori >= 10 AND Kalori <= 60) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 4 AND(Kalori >= 40 AND Kalori <= 65) ORDER BY NEWID())AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=7 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=4 AND (Kalori >=110 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 15 AND(Kalori >= 60 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=12 AND (Kalori >=138 AND Kalori <=150)  ORDER BY NEWID () ) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton7.Checked == true && int.Parse(TextBox1.Text) >= 2400 && int.Parse(TextBox1.Text) < 2600)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=290)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 21 AND(Kalori >= 220 AND Kalori <= 240) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 8 AND(Kalori >= 40 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND  Besin_Category_ID = 11 AND(Kalori >= 90 AND Kalori <= 120) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 4 AND(Kalori >= 60 AND Kalori <= 85) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=3 AND (Kalori >=130 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=7 AND (Kalori >=136 AND Kalori <=145) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 4 AND(Kalori >= 121 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 15 AND(Kalori >= 63 AND Kalori <= 70) ORDER BY NEWID()) AS K ", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=12 AND (Kalori >=150 AND Kalori <=165)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton7.Checked == true && int.Parse(TextBox1.Text) >= 2600 && int.Parse(TextBox1.Text) < 2800)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=220 AND Kalori <=235) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=2  AND (Kalori >=40 AND Kalori <=55)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID() ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=3 AND (Kalori >=100 AND Kalori <=120)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=7 AND (Kalori >=140 AND Kalori <=160) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=21 AND (Kalori >=240 AND Kalori <=260) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 8 AND(Kalori >= 45 AND Kalori <= 90) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 115) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=3 AND (Kalori >=150 AND Kalori <=160)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=7 AND (Kalori >=155 AND Kalori <=165) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=4 AND (Kalori >=120 AND Kalori <=130) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=15 AND (Kalori >=60 AND Kalori <=70) ORDER BY NEWID ()) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=12 AND (Kalori >=163 AND Kalori <=175)  ORDER BY NEWID ()  ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              }

              else if (RadioButton7.Checked == true && int.Parse(TextBox1.Text) >= 2800 && int.Parse(TextBox1.Text) < 3000)
              {

                  SqlCommand cmdegzersiz = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=5 AND (Kalori >=255 AND Kalori <=275)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=255 AND Kalori <=265) ORDER BY NEWID () UNION SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=75 AND Kalori <=90) ORDER BY NEWID () UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=2  AND (Kalori >=50 AND Kalori <=60)ORDER BY  NEWID() UNION SELECT TOP (1) * from [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=17 AND (Kalori >=0 AND Kalori <=500)ORDER BY  NEWID()  UNION SELECT TOP (2) * from [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=1 AND (Kalori >=30 AND Kalori <=40)ORDER BY  NEWID()  ) AS T", baglan.baglan());

                  SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

                  DataList1.DataSource = dregzersiz;

                  DataList1.DataBind();


                  SqlCommand cmdegzersiz1 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=7 AND (Kalori >=190 AND Kalori <=210) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=21 AND (Kalori >=210 AND Kalori <=230) ORDER BY NEWID () UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 8 AND(Kalori >= 65 AND Kalori <= 110) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 11 AND(Kalori >= 110 AND Kalori <= 130) ORDER BY NEWID() UNION SELECT TOP(1) * FROM[Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID = 4 AND(Kalori >= 80 AND Kalori <= 120) ORDER BY NEWID()) AS K  ", baglan.baglan());

                  SqlDataReader dregzersiz1 = cmdegzersiz1.ExecuteReader();

                  DataList2.DataSource = dregzersiz1;

                  DataList2.DataBind();


                  SqlCommand cmdegzersiz2 = new SqlCommand("SELECT * FROM ( SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=3 AND (Kalori >=120 AND Kalori <=140)  ORDER BY NEWID ()  UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=7 AND (Kalori >=130 AND Kalori <=150) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=4 AND (Kalori >=100 AND Kalori <=120) ORDER BY NEWID () UNION SELECT TOP (1) * FROM [Diyet].[dbo].[Besinler]  WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=15 AND (Kalori >=110 AND Kalori <=150) ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz2 = cmdegzersiz2.ExecuteReader();

                  DataList3.DataSource = dregzersiz2;

                  DataList3.DataBind();


                  SqlCommand cmdegzersiz3 = new SqlCommand("SELECT * FROM ( SELECT TOP (2) * FROM [Diyet].[dbo].[Besinler] WHERE Hastalık_ID Not Like '%6%' AND Besin_Category_ID=12 AND (Kalori >=175 AND Kalori <=188)  ORDER BY NEWID () ) AS K", baglan.baglan());

                  SqlDataReader dregzersiz3 = cmdegzersiz3.ExecuteReader();

                  DataList4.DataSource = dregzersiz3;

                  DataList4.DataBind();

              } */




        }

    } 
}