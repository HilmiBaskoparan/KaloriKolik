﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace KaloriKolik2
{
    public partial class _default : System.Web.UI.Page
    {
        sqlbaglanti baglan = new sqlbaglanti();

        protected void Page_Load(object sender, EventArgs e)
        {

            SqlCommand cmdslider = new SqlCommand("Select * from Makale", baglan.baglan());

            SqlDataReader drslider = cmdslider.ExecuteReader();

            DataList1.DataSource = drslider;

            DataList1.DataBind();


        }

    }
}