﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KaloriKolik2.admin
{
    public partial class besinler : System.Web.UI.Page
    {
            sqlbaglanti baglan = new sqlbaglanti();
        string Besin_ID = "";
        string islem = "";

            protected void Page_Load(object sender, EventArgs e)
            {
            Besin_ID = Request.QueryString["Besin_ID"];
            islem = Request.QueryString["islem"];

            if (islem == "sil")
            {
                SqlCommand cmdsil = new SqlCommand("Delete from Besinler where Besin_ID='"+Besin_ID+"'",baglan.baglan());
                cmdsil.ExecuteNonQuery();
            }



            //besin

            SqlCommand cmdbesin = new SqlCommand("Select * from Besinler", baglan.baglan());

                SqlDataReader drbesin = cmdbesin.ExecuteReader();

                DataList1.DataSource = drbesin;

                DataList1.DataBind();

            }
        

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text != "" && TextBox2.Text != "" && TextBox3.Text != "" && TextBox4.Text != "" && TextBox5.Text != "" && TextBox6.Text != "" && TextBox7.Text != "" && TextBox8.Text != "" && TextBox9.Text != "")
            {
                SqlCommand cmdbekle = new SqlCommand("insert into Besinler(Besin_Adı,Besin_Category_ID,Kalori,Protein,Yağ,Karbonhidrat,Besin_Miktari,Açıklamalar,Hastalık_ID) Values ('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox8.Text + "','" + TextBox9.Text + "')", baglan.baglan());

                cmdbekle.ExecuteNonQuery();
                Response.Redirect("besinler.aspx");
            }
            else Button1.Text = "eksik!";
        }
    }
}

























