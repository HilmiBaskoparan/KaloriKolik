﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace KaloriKolik2.admin
{
    public partial class iletisim : System.Web.UI.Page
    {
        sqlbaglanti baglan = new sqlbaglanti();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text != "" && TextBox2.Text != "" && TextBox3.Text != "")
            {

                
                SqlCommand cmdekle = new SqlCommand("insert into Iletisim(IletisimAdSoyad,IletisimEmail,IletisimTelefon) Values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "')", baglan.baglan());

                cmdekle.ExecuteNonQuery();
                Response.Redirect("iletisim.aspx");

            }
            else Button1.Text = "Eksik!";
        }
    }
}