﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KaloriKolik2.admin
{
    public partial class makaleler : System.Web.UI.Page
    {
        sqlbaglanti baglan = new sqlbaglanti();
        string MakaleID = "";
        string islem = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            MakaleID = Request.QueryString["MakaleID"];
            islem = Request.QueryString["islem"];

            if (islem == "sil")
            {
                SqlCommand cmdsil = new SqlCommand("Delete from Makale where MakaleID='" + MakaleID + "'", baglan.baglan());
                cmdsil.ExecuteNonQuery();
            }
            //besin

            SqlCommand cmdmakale = new SqlCommand("Select * from Makale", baglan.baglan());

            SqlDataReader drmakale = cmdmakale.ExecuteReader();

            DataList1.DataSource = drmakale;

            DataList1.DataBind();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            if (FileUpload1.HasFile && TextBox1.Text != "" && TextBox2.Text != "" && TextBox3.Text != "")
            {

                FileUpload1.SaveAs(Server.MapPath("/sresim/" + FileUpload1.FileName));
                SqlCommand cmdekle = new SqlCommand("insert into Makale(MakaleBaslik,MakaleOzet,MakaleIcerik,MakaleResim) Values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','/sresim/" + FileUpload1.FileName + "')", baglan.baglan());

                cmdekle.ExecuteNonQuery();
                Response.Redirect("makaleler.aspx");

            }
            else Button1.Text = "Eksik!";


        }
    }
}
