﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace KaloriKolik2.admin
{
    

    public partial class egzersiz : System.Web.UI.Page
    {
        sqlbaglanti baglan = new sqlbaglanti();
        string EgzersizID = "";
        string islem = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            EgzersizID = Request.QueryString["EgzersizID"];
            islem = Request.QueryString["islem"];

            if (islem == "sil")
            {
                SqlCommand cmdsil = new SqlCommand("Delete from Egzersiz where EgzersizID='" + EgzersizID + "'", baglan.baglan());
                cmdsil.ExecuteNonQuery();
            }
            //besin

            SqlCommand cmdegzersiz = new SqlCommand("Select * from Egzersiz", baglan.baglan());

            SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

            DataList1.DataSource = dregzersiz;

            DataList1.DataBind();

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile && TextBox1.Text != "" && TextBox2.Text != "" && TextBox3.Text != "")
            {

                FileUpload1.SaveAs(Server.MapPath("/eresim/" + FileUpload1.FileName));
                SqlCommand cmdekle = new SqlCommand("insert into Egzersiz(EgzersizBaslik,EgzersizOzet,EgzersizIcerik,EgzersizResim) Values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','/eresim/" + FileUpload1.FileName + "')", baglan.baglan());

                cmdekle.ExecuteNonQuery();
                Response.Redirect("egzersiz.aspx");

            }
            else Button1.Text = "Eksik!";

        }
    }
}