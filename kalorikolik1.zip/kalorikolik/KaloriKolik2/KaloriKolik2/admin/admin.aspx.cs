﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace KaloriKolik2.admin
{
    public partial class admin : System.Web.UI.Page
    {
        sqlbaglanti baglan = new sqlbaglanti();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Select * from Admin where YoneticiKullanici='"+TextBox1.Text+"' and YoneticiSifre ='"+TextBox2.Text+"'", baglan.baglan()) ;
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                Response.Redirect("adminpanel.aspx");
            }
            else Label1.Text = "Hatalı Giriş";
        }

    }
}