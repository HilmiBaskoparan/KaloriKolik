﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace KaloriKolik2
{
    public partial class EgzersizDetay : System.Web.UI.Page
    {
        sqlbaglanti baglan = new sqlbaglanti();
        string EgzersizID = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            EgzersizID = Request.QueryString["EgzersizID"];

            //egzersiz

            SqlCommand cmdegzersiz = new SqlCommand("Select * from Egzersiz where EgzersizID='"+EgzersizID+"'", baglan.baglan());

            SqlDataReader dregzersiz = cmdegzersiz.ExecuteReader();

            DataList1.DataSource = dregzersiz;

            DataList1.DataBind();

        }
    }
}