﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KaloriKolik2
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        double sayi1;
        double sayi2;
        double sayi3;
        double sayi4;
        double sayi5;

        void Temizlik1()
        {
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox5.Text = "";
        }
        void Temizlik2()
        {
            TextBox7.Text = "";
            TextBox6.Text = "";
            
        }

        void VeriAl1()
        {
            sayi4 = Convert.ToDouble(TextBox7.Text);
            sayi5 = Convert.ToDouble(TextBox6.Text);
           
        }
        void VeriAl2()
        {
            sayi1 = Convert.ToDouble(TextBox2.Text);
            sayi2 = Convert.ToDouble(TextBox3.Text);
            sayi3 = Convert.ToDouble(TextBox5.Text);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

            VeriAl1();
            double a = sayi4 / 100;
            double b = a * a;
            double vke = sayi5 / b;
            TextBox1.Text = vke.ToString();
            double ivke = b * 23.5;
            TextBox8.Text = ivke.ToString();
            
            if (vke < 18.5)
            {
                Label8.Text = "zayıf";
            }
            else if (18.5<=vke && vke<25)
            {
                Label8.Text = "Normal";
            }
            else if (25 <= vke && vke < 30)
            {
                Label8.Text = "Fazla Kilolu";
            }
            else if (30 <= vke && vke < 35)
            {
                Label8.Text = "1. Derece Obez";
            }
            else if (35 <= vke && vke < 40)
            {
                Label8.Text = "2. Derece Obez";
            }
            else if (40 <= vke)
            {
                Label8.Text = "3. Derece Morbid Obez";
            }

            Temizlik2();

        }

 

        protected void Button1_Click(object sender, EventArgs e)
        {
            VeriAl2();

            if (RadioButton1.Checked)
            {
                if(DropDownList1.Text=="Lütfen Bir Seçim Yapın")
                {
                    Label7.Text = "Lütfen egzersiz seçimi yapın";
                }
                else if (DropDownList1.Text == "Egzersiz Yapmıyorum(masa başı iş)")
                {
                    if (DropDownList2.Text == "Kilomu Korumak İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.2 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        TextBox9.Text = sonuc.ToString();

                    }

                    else if (DropDownList2.Text == "1 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.2 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 230;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "2 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.2 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 460;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "3 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.2 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 690;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "1 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.2 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 230;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "2 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.2 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 460;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "3 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.2 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 690;
                        TextBox9.Text = sonuc1.ToString();
                    }

                }
                else if (DropDownList1.Text == "Çok Az Egzersiz Yapıyorum(az hareketli iş)")
                {
                    if (DropDownList2.Text == "Kilomu Korumak İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.375 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        TextBox9.Text = sonuc.ToString();
                    }
                    else if (DropDownList2.Text == "1 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.375 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 230;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "2 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.375 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 460;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if(DropDownList2.Text == "3 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.375 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 690;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "1 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.375 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 230;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "2 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.375 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 460;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "3 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.375 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 690;
                        TextBox9.Text = sonuc1.ToString();
                    }

                }
                else if (DropDownList1.Text == "Az Yoğun Egzersiz Yapıyorum(orta derecede hareketli iş)")
                {
                    if (DropDownList2.Text == "Kilomu Korumak İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.55 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        TextBox9.Text = sonuc.ToString();
                    }
                    else if (DropDownList2.Text == "1 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.55 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 230;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "2 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.55 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 460;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "3 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.55 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 690;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "1 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.55 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 230;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "2 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.55 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 460;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "3 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.55 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 690;
                        TextBox9.Text = sonuc1.ToString();
                    }

                }
                else if (DropDownList1.Text == "Yoğun Egzersiz Yapıyorum(çok aktif bir iş)")
                {
                    if (DropDownList2.Text == "Kilomu Korumak İstiyorum")
                    {

                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.725 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        TextBox9.Text = sonuc.ToString();
                    }
                    else if (DropDownList2.Text == "1 Kilo Almak İstiyorum")
                    {

                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.725 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 230;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "2 Kilo Almak İstiyorum")
                    {

                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.725 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 460;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "3 Kilo Almak İstiyorum")
                    {

                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.725 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 690;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "1 Kilo Vermek İstiyorum")
                    {

                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.725 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 230;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "2 Kilo Vermek İstiyorum")
                    {

                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.725 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 460;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "3 Kilo Vermek İstiyorum")
                    {

                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.725 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 690;
                        TextBox9.Text = sonuc1.ToString();

                    }


                }
                else if (DropDownList1.Text == "Çok Yoğun Egzersiz Yapıyorum")
                {
                    if (DropDownList2.Text == "Kilomu Korumak İstiyorum")
                    {

                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.9 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        TextBox9.Text = sonuc.ToString();
                    }
                    else if (DropDownList2.Text == "1 Kilo Almak İstiyorum")
                    {

                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.9 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 230;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "2 Kilo Almak İstiyorum")
                    {

                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.9 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 460;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "3 Kilo Almak İstiyorum")
                    {

                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.9 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 690;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "1 Kilo Vermek İstiyorum")
                    {

                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.9 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 230;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "2 Kilo Vermek İstiyorum")
                    {

                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.9 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 460;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "3 Kilo Vermek İstiyorum")
                    {

                        double a = sayi2 * 13.75;
                        double b = 5 * sayi1;
                        double c = 6.8 * sayi3;
                        double sonuc = 1.9 * (66 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 690;
                        TextBox9.Text = sonuc1.ToString();

                    }

                }
            }

            if (RadioButton2.Checked)
            {
                if (DropDownList1.Text == "Lütfen Bir Seçim Yapın")
                {
                    Label7.Text = "Lütfen egzersiz seçimi yapın";
                }
                else if (DropDownList1.Text == "Egzersiz Yapmıyorum(masa başı iş)")
                {
                    if (DropDownList2.Text == "Kilomu Korumak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.2 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        TextBox9.Text = sonuc.ToString();

                    }

                    else if (DropDownList2.Text == "1 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.2 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 230;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "2 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.2 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 460;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "3 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.2 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 690;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "1 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.2 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 230;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "2 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.2 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 460;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "3 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.2 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 690;
                        TextBox9.Text = sonuc1.ToString();
                    }

                }
                else if (DropDownList1.Text == "Çok Az Egzersiz Yapıyorum(az hareketli iş)")
                {
                    if (DropDownList2.Text == "Kilomu Korumak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.375 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        TextBox9.Text = sonuc.ToString();

                    }

                    else if (DropDownList2.Text == "1 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.375 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 230;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "2 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.375 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 460;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "3 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.375 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 690;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "1 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.375 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 230;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "2 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.375 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 460;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "3 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.375 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 690;
                        TextBox9.Text = sonuc1.ToString();
                    }
                }
                else if (DropDownList1.Text == "Az Yoğun Egzersiz Yapıyorum(orta derecede hareketli iş)")
                {
                    if (DropDownList2.Text == "Kilomu Korumak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.55 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        TextBox9.Text = sonuc.ToString();

                    }

                    else if (DropDownList2.Text == "1 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.55 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 230;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "2 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.55 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 460;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "3 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.55 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 690;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "1 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.55 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 230;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "2 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.55 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 460;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "3 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.55 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 690;
                        TextBox9.Text = sonuc1.ToString();
                    }
                }
                else if (DropDownList1.Text == "Yoğun Egzersiz Yapıyorum(çok aktif bir iş)")
                {

                    if (DropDownList2.Text == "Kilomu Korumak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.725 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        TextBox9.Text = sonuc.ToString();

                    }

                    else if (DropDownList2.Text == "1 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.725 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 230;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "2 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.725 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 460;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "3 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.725 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 690;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "1 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.725 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 230;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "2 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.725 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 460;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "3 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.725 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 690;
                        TextBox9.Text = sonuc1.ToString();
                    }
                }
                else if (DropDownList1.Text == "Çok Yoğun Egzersiz Yapıyorum")
                {
                    if (DropDownList2.Text == "Kilomu Korumak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.9 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        TextBox9.Text = sonuc.ToString();

                    }

                    else if (DropDownList2.Text == "1 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.9 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 230;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "2 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.9 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 460;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "3 Kilo Almak İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.9 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc + 690;
                        TextBox9.Text = sonuc1.ToString();

                    }
                    else if (DropDownList2.Text == "1 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.9 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 230;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "2 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.9 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 460;
                        TextBox9.Text = sonuc1.ToString();
                    }
                    else if (DropDownList2.Text == "3 Kilo Vermek İstiyorum")
                    {
                        double a = sayi2 * 9.6;
                        double b = 1.7 * sayi1;
                        double c = 4.7 * sayi3;
                        double sonuc = 1.9 * (665 + a + b - c);
                        TextBox4.Text = sonuc.ToString();
                        double sonuc1 = sonuc - 690;
                        TextBox9.Text = sonuc1.ToString();
                    }
                }
                
            }
            Temizlik1();
        }

        protected void btnarama_Click(object sender, EventArgs e)
        {
            Response.Redirect("besinara.aspx?aranankelime=" + txtarama.Text);
        }
    }
}